<?php
/******************************************************************************
 * Datei:				xmlrpc.php
 * Autor:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Datum:				2004-05-14
 * Letzte �nderung:		2004-08-09
 * Copyright:           (c) 2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

/* debug mode:
 * - FALSE	debug mode disabled
 * - TRUE	debug mode enabled
 */
define("DEBUG", FALSE);

if (DEBUG == TRUE) {
	error_reporting(E_ALL);
	}

/* connect to the database server */
require_once("inc/data.php");
require_once("inc/mysql.php");
define("SQLPREFIX", $DB["prefix"]);
$db = new DB();
$db->connect($DB["server"], $DB["user"], $DB["password"], $DB["db"]);

/* get configuration, constants, main functions, category class, XML-RPC classes */
require_once("inc/config.php");
require_once("inc/constants.php");
require_once("inc/functions.php");
require_once("inc/category.php");
include_once("inc/xmlrpc.php");
include_once("inc/xmlrpcs.php");

$tree = new Category();

function search($begriff)
{
	global $db, $tree, $PMF_LANG, $PMF_CONF;
	$output = "";
	$begriff = safeSQL(trim($begriff));
	
    if (mysql_check("4.0.1") == FALSE) {
        $query = "SELECT id, lang, rubrik, thema FROM ".SQLPREFIX."faqdata WHERE MATCH (thema,content,keywords) AGAINST ('".$begriff."') AND active = 'yes'";
        }
    else {
        $query = "SELECT id, lang, rubrik, thema FROM ".SQLPREFIX."faqdata WHERE MATCH (thema,content,keywords) AGAINST ('".str_replace(" ", "* ", trim($begriff))."*' IN BOOLEAN MODE) AND active = 'yes'";
        }
    
	$result = $db->query($query);
	if ($db->num_rows($result) > 0) {
        $output .= $num.$PMF_LANG["msgSearchAmounts"]."\n";
	    while ($row = $db->fetch_object($result)) {
			$rubriktext = $tree->categoryName[$row->rubrik]["name"];
			$thema = chopString($row->thema, 15);
            $output .= htmlentities($rubriktext).";".htmlentities($row->thema).";"."http://".$_SERVER["HTTP_HOST"].str_replace ("xmlrpc.php", "index.php", $_SERVER["PHP_SELF"])."?action=artikel&cat=".$row->rubrik."&id=".$row->id."&artlang=".$row->lang."\n";
            }
        }
    else {
		$output = "No Articles found";
		}
    
	return $output;
}

function PMFSearch($params)
{
    $param = $params->getParam(0);
    if (isset($param)) {
        if ($param->scalartyp() == "string") {
            $searchString = $param->scalarval();
            $ret = new xmlrpcval(search($searchString), "string");
            return new xmlrpcresp($ret);
        }
        else {
            global $xmlrpcerruser;
            $ret = new xmlrpcresp(0, $xmlrpcerruser, "Wrong Parameter!");
            return $ret;
            }
        }
    else {
        global $xmlrpcerruser;
        $ret = new xmlrpcresp(0, $xmlrpcerruser, "No data received from client!");
        return $ret;
        }
}

$xmlrpc = new xmlrpc_server(array("phpmyfaq.PMFSearch" => array("function" => "PMFSearch")));

$db->dbclose();
?>