<?php
/******************************************************************************
 * Author:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2002-08-20
 * Last Update:			2005-03-12
 * Copyright:           (c) 2001-2005 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 */

define("VERSION", "1.4.8");
define("COPYRIGHT", "&copy; 2001-2004 <a href=\"http://www.phpmyfaq.de/\">phpMyFAQ-Team</a> | All rights reserved.");
define("SAFEMODE", @ini_get("safe_mode"));
define("PMF_ROOT_DIR", dirname(dirname(__FILE__)));

require_once(PMF_ROOT_DIR."/inc/constants.php");

function version_check ($ist = "", $soll = "", $err_msg = "")
{
    if (empty($ist) OR empty($soll)) {
        return FALSE;
        }
    $ist = explode(".", $ist);
    $soll = explode(".", $soll);
    $num = count($soll);
    for ($i = 0; $i < $num; $i++) {
        if ($ist[$i] <  $soll[$i]) {
            return FALSE;
            }
        if ($ist[$i] == $soll[$i]) {
            continue;
            }
        if ($ist[$i] >= $soll[$i]) {
            return TRUE;
            }
        }
    return TRUE;
}

function mysql_check($version)
{
    return version_check(mysql_get_client_info(), $version);
}

function php_check($version)
{
    return version_check(phpversion(), $version);
}

function phpmyfaq_check($file)
{
    if (@include($file)) {
        include($file);
        // check for version 1.3.x
        if ((isset($mysql_server) && $mysql_server != "") || (isset($mysql_user) && $mysql_user != "") || (isset($mysql_passwort) && $mysql_passwort != "") || (isset($mysql_db) && $mysql_db != "")) {
            return FALSE;
            }
        // check for version 1.4.x
        if ((isset($DB["server"]) && $DB["server"] != "") || (isset($DB["user"]) && $DB["user"] != "") || (isset($DB["password"]) && $DB["password"] != "") || (isset($DB["db"]) && $DB["db"] != "") || (isset($DB["prefix"]) && $DB["prefix"] != "")) {
            return FALSE;
            }
        return TRUE;
        }
    return TRUE;
}

function uninstall() {
	global $uninst, $db;
	while ($each_query = each($uninst)) {
		$result = $db->query($each_query[1]);
		}
	}

function HTMLFooter() {
	print "<p class=\"center\">".COPYRIGHT."</p>\n</body>\n</html>";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <title>phpMyFAQ <?php print VERSION; ?> Installation</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <style type="text/css"><!--
    body {
	    margin: 0px;
	    padding: 0px;
	    font-size: 12px;
	    font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	    background-color: #B0B0B0;
    }
    #header {
	    margin: auto;
	    padding: 35px;
	    background-color: #6A88B1;
        text-align: center;
    }
    #header h1 {
	    font: bold 36px Garamond, times, serif;
	    margin: auto;
	    color: #f5f5f5;
        text-align: center;
    }
    .center {
        text-align: center;
    }
    fieldset.installation {
        margin: auto;
        border: 1px solid black;
        width: 550px;
    }
    legend.installation {
        border: 1px solid black;
        background-color: #FCE397;
        padding: 4px 4px 4px 4px;
    }
    .input {
        width: 200px;
        background-color: #f5f5f5;
        border: 1px solid black;
    }
    span.text {
        width: 250px;
        float: left;
        text-align: right;
        padding-right: 10px;
        line-height: 20px;
    }
    #admin {
        line-height: 20px;
        font-weight: bold;
    }
    .help {
        cursor: help;
        border-bottom: 1px dotted Black;
        font-size: 14px;
        font-weight: bold;
        padding-left: 5px;
    }
    .button {
        background-color: #ff7f50;
        border: 1px solid #000000;
        color: #ffffff;
    }
    .error {
        margin: auto;
        margin-top: 20px;
        width: 600px;
        text-align: center;
        padding: 10px;
        line-height: 20px;
        background-color: #f5f5f5;
        border: 1px solid black;
    }
    --></style>
</head>
<body>

<h1 id="header">phpMyFAQ <?php print VERSION; ?> Installation</h1>

<?php
if (php_check("4.1.0") == FALSE) {
	print "<p class=\"center\">You need PHP Version 4.1.0 or higher!</p>\n";
	HTMLFooter();
	die();
	}
if (mysql_check("3.23.23") == FALSE) {
	print "<p class=\"center\">You need MySQL Version 3.23.23 or higher!</p>\n";
	HTMLFooter();
	die();
	}
if (!phpmyfaq_check(PMF_ROOT_DIR."/inc/data.php")) {
	print "<p class=\"center\">It seems you already running a version of phpMyFAQ.<br />Please use the <a href=\"update.php\">update script</a>.</p>\n";
	HTMLFooter();
	die();
	}
if (!is_dir(PMF_ROOT_DIR."/attachments")) {
    if (!mkdir (PMF_ROOT_DIR."/attachments", 0755)) {
        print "<p class=\"center\">The directory ../attachments could not be created.</p>\n";
	    HTMLFooter();
	    die();
        }
    }
if (!is_dir(PMF_ROOT_DIR."/data")) {
    if (!mkdir (PMF_ROOT_DIR."/data", 0755)) {
        print "<p class=\"center\">The directory ../data could not be created.</p>\n";
	    HTMLFooter();
	    die();
        }
    }
if (!is_dir(PMF_ROOT_DIR."/images")) {
    if (!mkdir (PMF_ROOT_DIR."/images", 0755)) {
        print "<p class=\"center\">The directory ../images could not be created.</p>\n";
	    HTMLFooter();
	    die();
        }
    }
if (!is_dir(PMF_ROOT_DIR."/pdf")) {
    if (!mkdir (PMF_ROOT_DIR."/pdf", 0755)) {
        print "<p class=\"center\">The directory ../pdf could not be created.</p>\n";
	    HTMLFooter();
	    die();
        }
    }
if (!is_writeable(PMF_ROOT_DIR."/inc") || !@copy("index.html", PMF_ROOT_DIR."/inc/index.html")) {
    print "<p class=\"center\">The directory ../inc is not writeable.</p>\n";
    HTMLFooter();
    die();
    }
if (!is_writeable(PMF_ROOT_DIR."/attachments") || !@copy("index.html", PMF_ROOT_DIR."/attachments/index.html")) {
    print "<p class=\"center\">The directory ../attachments is not writeable.</p>\n";
    HTMLFooter();
    die();
    }
if (!is_writeable(PMF_ROOT_DIR."/data") || !@copy("index.html", PMF_ROOT_DIR."/data/index.html")) {
    print "<p class=\"center\">The directory ../data is not writeable.</p>\n";
    HTMLFooter();
    die();
    }
if (!is_writeable(PMF_ROOT_DIR."/images") || !@copy("index.html", PMF_ROOT_DIR."/images/index.html")) {
    print "<p class=\"center\">The directory ../images is not writeable.</p>\n";
    HTMLFooter();
    die();
    }
if (!is_writeable(PMF_ROOT_DIR."/pdf") || !@copy("index.html", PMF_ROOT_DIR."/pdf/index.html")) {
	print "<p class=\"center\">The directory ../pdf is not writeable.</p>\n";
	HTMLFooter();
	die();
	}
if (!is_writeable(PMF_ROOT_DIR."/xml") || !@copy("index.html", PMF_ROOT_DIR."/xml/index.html")) {
	print "<p class=\"center\">The directory ../xml is not writeable.</p>\n";
	HTMLFooter();
	die();
	}
if (!isset($_POST["database_server"]) AND !isset($_POST["database_user"]) AND !isset($_POST["database_db"])) {
?>

<p class="center">Your PHP version: <strong>PHP <?php print phpversion(); ?></strong> / Your MySQL client version: <strong>MySQL <?php print mysql_get_client_info(); ?></strong></p>

<?php
if (SAFEMODE == 1) {
    print "<p>The PHP safe mode is enabled. Maybe you'll getting problems when phpMyFAQ wants to write in some directories.</p>\n";
    }
?>

<p class="center">You should read the <a href="../docs/documentation.en.html">documentation</a> carefully before installing phpMyFAQ.</p>

<form action="<?php print $_SERVER["PHP_SELF"]; ?>" method="post">
<fieldset class="installation">
<legend class="installation"><strong>phpMyFAQ <?php print VERSION; ?> Installation</strong></legend>
<p>
<span class="text">Database server:</span>
<input class="input" type="text" name="database_server" />
<span class="help" title="Please enter the host of your database server here.">?</span>
</p>
<p>
<span class="text">Database username:</span>
<input class="input" type="text" name="database_user" />
<span class="help" title="Please enter your database username here.">?</span>
</p>
<p>
<span class="text">Database password:</span>
<input class="input" name="database_passwort" type="password" />
<span class="help" title="Please enter your database password here.">?</span>
</p>
<p>
<span class="text">Database database:</span>
<input class="input" type="text" name="database_db" />
<span class="help" title="Please enter your database database here.">?</span>
</p>
<p>
<span class="text">Table prefix:</span>
<input class="input" type="text" name="sqltblpre" />
<span class="help" title="Please enter a table prefix here if you want to install more phpMyFAQ installations on one database.">?</span>
</p>
<p>
<span class="text">Default language:</span>
<select class="input" name="language" size="1">
<?php
	if ($dir = @opendir(PMF_ROOT_DIR."/lang")) {
		while ($dat = @readdir($dir)) {
			if (substr($dat, -4) == ".php") {
				print "\t\t<option value=\"".$dat."\"";
				if ($dat == "language_en.php") {
					print " selected=\"selected\"";
					}
                print ">".$languageCodes[substr(strtoupper($dat), 9, 2)]."</option>\n";
				}
			}
		}
	else {
		print "\t\t<option>english</option>";
		}
?>
</select>
<span class="help" title="Please select your default language.">?</span>
</p>
<p>
<span class="text">Administrator's real name:</span>
<input class="input"  type="text" name="realname" />
<span class="help" title="Please enter your real name here.">?</span>
</p>
<p>
<span class="text">Administrator's e-mail address:</span>
<input class="input"  type="text" name="email" />
<span class="help" title="Please enter your email adress here.">?</span>
</p>
<p>
<span class="text">Administrator's username:</span>
<span id="admin">admin</span>
</p>
<p>
<span class="text">Administrator's password:</span>
<input class="input" type="password" name="password" />
<span class="help" title="Please enter your password for the admin area.">?</span>
</p>
<p>
<span class="text">Retype password:</span>
<input class="input" type="password" name="password_retyped" />
<span class="help" title="Please retype your password for checkup.">?</span>
</p>
<p class="center"><strong>Do not use if you're already running a version of phpMyFAQ!</strong></p>
<p class="center"><input type="submit" value="Install phpMyFAQ" class="button" /></p>
</fieldset>
</form>
<?php
    HTMLFooter();
	}
else {
	if (isset($_POST["database_server"]) && $_POST["database_server"] != "") {
		$database_server = $_POST["database_server"];
        }
    else {
        print "<p class=\"error\"><strong>Error:</strong> There's no database server input.</p>\n";
		HTMLFooter();
		die();
		}
	if (isset($_POST["database_user"]) && $_POST["database_user"] != "") {
		$database_user = $_POST["database_user"];
        }
    else {
        print "<p class=\"error\"><strong>Error:</strong> There's no database username input.</p>\n";
		HTMLFooter();
		die();
		}
    if (isset($_POST["database_passwort"]) && $_POST["database_passwort"] != "") {
		$database_passwort = $_POST["database_passwort"];
        }
    else {
        print "<p class=\"error\"><strong>Error:</strong> There's no database password input.</p>\n";
		HTMLFooter();
		die();
		}
    if (isset($_POST["database_db"]) && $_POST["database_db"] != "") {
		$database_db = $_POST["database_db"];
        }
    else {
        print "<p class=\"error\"><strong>Error:</strong> There's no database name input.</p>\n";
		HTMLFooter();
		die();
		}
    
    require_once(PMF_ROOT_DIR."/inc/mysql.php");
	$db = new DB();
    
    if (!($db->connect($database_server, $database_user, $database_passwort, $database_db))) {
		print "<p class=\"error\"><strong>Error:</strong> ".$db->error()."</p>\n";
		HTMLFooter();
		die();
		}
    if (isset($_POST["password"]) && $_POST["password"] != "") {
        $password = $_POST["password"];
        }
    else {
		print "<p class=\"error\"><strong>Error:</strong> There's no password. Please set your password.</p>\n";
		HTMLFooter();
		die();
        }
    if (isset($_POST["password_retyped"]) && $_POST["password_retyped"] != "") {
        $password_retyped = $_POST["password_retyped"];
        }
    else {
		print "<p class=\"error\"><strong>Error:</strong> There's no retyped password. Please set your retyped password.</p>\n";
		HTMLFooter();
		die();
		}
	if (strlen($password) <= 5 || strlen($password_retyped) <= 5) {
		print "<p class=\"error\"><strong>Error:</strong> Your password and retyped password are too short. Please set your password and your retyped password with a minimum of 6 characters.</p>\n";
		HTMLFooter();
		die();
		}
	if ($password != $password_retyped) {
		print "<p class=\"error\"><strong>Error:</strong> Your password and retyped password are not equal. Please check your password and your retyped password.</p>\n";
		HTMLFooter();
		die();
		}
    if (isset($_POST["sqltblpre"]) && $_POST["sqltblpre"] != "") {
        $sqltblpre = $_POST["sqltblpre"];
        }
    else {
        $sqltblpre = "";
	    }
    if (isset($_POST["language"]) && $_POST["language"] != "") {
        $language = $_POST["language"];
        }
    else {
        $language = "en";
	    }
    if (isset($_POST["realname"]) && $_POST["realname"] != "") {
        $realname = $_POST["realname"];
        }
    else {
        $realname = "";
	    }
    if (isset($_POST["email"]) && $_POST["email"] != "") {
        $email = $_POST["email"];
        }
    else {
        $email = "";
	    }
    
    /**
     * Write the DB variables in data.php
     */
    
	if ($fp = @fopen(PMF_ROOT_DIR."/inc/data.php","w")) {
		@fputs($fp,"<?php\n\$DB[\"server\"] = '".$database_server."';\n\$DB[\"user\"] = '".$database_user."';\n\$DB[\"password\"] = '".$database_passwort."';\n\$DB[\"db\"] = '".$database_db."';\n\$DB[\"prefix\"] = '".$sqltblpre."';\n?>");
		@fclose($fp);
		}
	else {
		print "<p class=\"error\"><strong>Error:</strong> Cannot write to data.php.</p>";
        HTMLFooter();
		die();
		}
    
    /**
     * Create config.php and write the language variables in the file
     */
    if (@file_exists(PMF_ROOT_DIR."/inc/config.php")) {
    	print "<p class=\"center\">A config file was found. Please backup ../inc/config.php and remove the file.</p>\n";
    	HTMLFooter();
    	die();
        }
    if (!@copy(PMF_ROOT_DIR."/inc/config.php.original", PMF_ROOT_DIR."/inc/config.php")) {
    	print "<p class=\"center\">Could not copy the file ../inc/config.php.original to ../inc/config.php.</p>\n";
    	HTMLFooter();
    	die();
        }
	if ($fp = @fopen(PMF_ROOT_DIR."/inc/config.php","r")) {
		$anz = 0;
		while($dat = fgets($fp,1024)) {
			$anz++;
			$inp[$anz] = $dat;
			}
		@fclose($fp);
		for ($h = 1; $h <= $anz; $h++) {
			if (str_replace("\$PMF_CONF[\"language\"] = \"en\";", "", $inp[$h]) != $inp[$h]) {
				$inp[$h] = "\$PMF_CONF[\"language\"] = \"".$language."\";\n";
				}
			}
		if ($fp = @fopen("../inc/config.php","w")) {
			for ($h = 1; $h <= $anz; $h++) {
				fputs($fp,$inp[$h]);
				}
			@fclose($fp);
			}
		else {
			print "<p>Cannot write to config.php.</p></td>";
            HTMLFooter();
		    die();
			}
		}
	else {
		print "<p>Cannot read config.php.</p></td>";
        HTMLFooter();
		die();
		}
	
    /**
     * connect to the database using inc/data.php
     */
    require_once(PMF_ROOT_DIR."/inc/data.php");
	$db = new DB();
    
	if (!($db->connect($DB["server"], $DB["user"], $DB["password"], $DB["db"]))) {
		print "<p class=\"error\"><strong>Error:</strong> ".$db->error()."</p>\n";
		HTMLFooter();
		die();
		}
    
	$uninst[] = "DROP TABLE ".$sqltblpre."faqadminlog";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqadminsessions";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqcategories";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqchanges";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqcomments";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqdata";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqfragen";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqnews";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqvoting";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqsessions";
	$uninst[] = "DROP TABLE ".$sqltblpre."faquser";
	$uninst[] = "DROP TABLE ".$sqltblpre."faqvisits";
	
    $query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqadminlog (
	id int(11) NOT NULL auto_increment,
	time int(11) NOT NULL,
	usr int(11) NOT NULL,
	text text NOT NULL,
	ip text NOT NULL,
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqadminsessions (
	uin varchar(50) BINARY NOT NULL,
	usr tinytext NOT NULL,
	pass varchar(64) BINARY NOT NULL,
	ip text NOT NULL,
	time int(11) NOT NULL)";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqcategories (
    id INT(11) NOT NULL AUTO_INCREMENT,
    lang VARCHAR(5) NOT NULL,
    parent_id INT(11) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(255) NOT NULL ,
    PRIMARY KEY (id,lang))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqchanges (
	id int(11) NOT NULL auto_increment,
	beitrag int(11) NOT NULL,
	lang varchar(5) NOT NULL,
	usr int(11) NOT NULL,
	datum int(11) NOT NULL,
	what text NOT NULL,
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqcomments (
	id_comment int(11) NOT NULL auto_increment,
	id int(11) NOT NULL,
	usr varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	comment text NOT NULL,
	datum int(15) NOT NULL,
	helped text NOT NULL,
	PRIMARY KEY (id_comment))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqdata (
	id int(11) NOT NULL auto_increment,
	lang varchar(5) NOT NULL,
	active char(3) NOT NULL,
	rubrik text NOT NULL,
	keywords text NOT NULL,
	thema text NOT NULL,
	content longtext NOT NULL,
	author varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	comment enum('y','n') NOT NULL default 'y',
	datum varchar(15) NOT NULL,
	FULLTEXT (keywords,thema,content),
	PRIMARY KEY (id, lang)) TYPE = MYISAM";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqfragen (
	id int(11) unsigned NOT NULL auto_increment,
	ask_username varchar(100) NOT NULL,
	ask_usermail varchar(100) NOT NULL,
	ask_rubrik varchar(100) NOT NULL,
	ask_content text NOT NULL,
	ask_date varchar(20) NOT NULL,
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqnews (
	id int(11) NOT NULL auto_increment,
	header varchar(255) NOT NULL,
	artikel text NOT NULL,
	datum varchar(14) NOT NULL,
	link varchar(255) NOT NULL,
	linktitel varchar(255) NOT NULL,
	target varchar(255) NOT NULL,
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqvoting (
	id int(11) unsigned NOT NULL auto_increment,
	artikel int(11) unsigned NOT NULL,
	vote int(11) unsigned NOT NULL,
	usr int(11) unsigned NOT NULL,
	datum varchar(20) NOT NULL default '',
	ip varchar(15) NOT NULL default '',
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqsessions (
	sid int(11) NOT NULL auto_increment,
	ip text NOT NULL,
	time int(11) NOT NULL,
	PRIMARY KEY sid (sid))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faquser (
	id int(2) NOT NULL auto_increment,
	name text NOT NULL,
	pass varchar(64) BINARY NOT NULL,
	realname varchar(255) NOT NULL default '',
	email varchar(255) NOT NULL default '',
	rights varchar(255) NOT NULL,
	PRIMARY KEY (id))";
	$query[] = "CREATE TABLE IF NOT EXISTS ".$sqltblpre."faqvisits (
	id int(11) NOT NULL auto_increment,
	lang varchar(5) NOT NULL,
	visits int(11) NOT NULL,
	last_visit int(15) NOT NULL,
	PRIMARY KEY (id, lang))";
    
	$query[] = "INSERT INTO ".$sqltblpre."faquser (id, name, pass, realname, email, rights) VALUES (1, 'admin', MD5('".$password."'), '".$realname."', '".$email."', '1111111111111111111111')";
	
	print "<p class=\"center\"><strong>";
	while ($each_query = each($query)) {
		$result = $db->query($each_query[1]);
		print "|&nbsp;";
		if (!$result) {
			print "<!-- ".$each_query[1]." --><p class=\"error\"><strong>Error:</strong> Please install your version of phpMyFAQ once again or send us a <a href=\"http://bugs.phpmyfaq.de\" target=\"_blank\">bug report</a>.<br />MySQL error: ".$db->error()."</p>/n";
			uninstall();
		    HTMLFooter();
		    die();
			}
        usleep(250);
		}
	print "</strong></p>\n";
    
    $db->dbclose();
	
    print "<p class=\"center\">All tables were created and filled with the data.</p>\n";
    print "<p class=\"center\">Congratulation! Everything seems to be okay.</p>\n";
    print "<p class=\"center\">You can visit <a href=\"../index.php\">your version of phpMyFAQ</a> or</p>\n";
    print "<p class=\"center\">login into your <a href=\"../admin/index.php\">admin section</a>.</p>\n";
    
    if (@unlink(basename($_SERVER["PHP_SELF"]))) {
        print "<p class=\"center\">This file was deleted automatically.</p>\n";
        }
    else {
        print "<p class=\"center\">Please delete this file manually.</p>\n";
        }
    if (@unlink(dirname($_SERVER["PATH_TRANSLATED"])."/update.php")) {
        print "<p class=\"center\">The file 'update.php' was deleted automatically.</p>\n";
        }
    else {
        print "<p class=\"center\">Please delete the file 'update.php' manually.</p>\n";
        }
        HTMLFooter();
    }
?>
