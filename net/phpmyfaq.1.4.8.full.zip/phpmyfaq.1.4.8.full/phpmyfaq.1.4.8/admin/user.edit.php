<?php
/******************************************************************************
 * File:				user.edit.php
 * Description:			delete an user
 * Authors:				Thorsten Rinne		thorsten@phpmyfaq.de
 * Date:				2003-02-21
 * Last change:			2004-06-06
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/
if ($permission["edituser"]) {
	adminlog("Useredit, ".$_GET["id"]);
	list($name, $pass, $realname, $email, $rights) = $db->fetch_row($db->query("SELECT name, pass, realname, email, rights FROM ".SQLPREFIX."faquser WHERE id = '".$_GET["id"]."'"));
?>
    <h2><?php print $PMF_LANG["ad_menu_user_administration"]; ?></h2>
    <form name="userRights" action="<?php print $_SERVER["PHP_SELF"].$linkext; ?>" method="POST">
    <fieldset>
    <legend><?php print $PMF_LANG["ad_user_profou"]; ?> <span style="color: Red; font-style: italic;"><?php print $name; ?></span></legend>
	<input type="hidden" name="aktion" value="usersave" />
	<input type="hidden" name="id" value="<?php print $_REQUEST["id"]; ?>" />
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_name"]; ?>:</strong></span>
<?php
	if (strtolower($name) != "admin") {
		print "<input class=\"admin\" type=\"text\" name=\"name\" size=\"30\" value=\"".$name."\">";
		}
	else {
		print $name;
		print "<input type=\"hidden\" name=\"name\" size=\"30\" value=\"".$name."\">";
		}
?></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_realname"]; ?></strong></span>
    <input class="admin" type="text" style="width: 200px;" name="realname" value="<?php print $realname; ?>" /></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_entry_email"]; ?></strong></span>
    <input class="admin" type="text" style="width: 200px;" name="email" value="<?php print $email; ?>" /></div>
<?php
	if ($user != $name) {
?>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_password"]; ?>:</strong></span>
    <input class="admin" name="npass" style="width: 200px;" type="password" /></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_confirm"]; ?>:</strong></span>
    <input class="admin" name="nupass" style="width: 200px;" type="password" /></div>
<?php
		}
	else {
?>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_password"]; ?>:</strong></span>
    <?php print $PMF_LANG["ad_user_chpw"]; ?></div>
<?php
		}
    if (strtolower($name) != "admin") {
?>
	</fieldset>
    <fieldset>
    <legend><?php print $PMF_LANG["ad_user_rights"]; ?> <span style="color: Red; font-style: italic;"><?php print $name; ?></span></legend>
    <div id="userrights">
<?php
        for ($i = 1; $i <= strlen($rights); $i++) {
            if (substr($rights, ($i - 1), 1) == 1) {
                $suf = " checked=\"checked\"";
                }
		    else {
			    unset($suf);
			    }
?>
        <input type="checkbox" name="right[<?php print $i-1; ?>]" value="1"<?php if (isset($suf)) { print $suf; } ?> /> <?php print $PMF_LANG["rightsLanguage"][$i-1]; ?><br />
<?php
		    }
?>
        <p><input type="checkbox" onClick="checkAll(this);" /> <?php print $PMF_LANG["ad_user_checkall"]; ?></p>
    </div>
<?php
		}
?>
	<div class="row"><span class="label"><strong>&nbsp;</strong></span>
    <input class="submit" type="submit" value="<?php print $PMF_LANG["ad_gen_save"]; ?>" /> <input type="reset" value="<?php print $PMF_LANG["ad_gen_reset"]; ?>" class="submit" /></div>
    </fieldset>
	</form>
<?php
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user\">".$PMF_LANG["ad_menu_user_administration"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>