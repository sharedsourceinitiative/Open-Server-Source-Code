<?php
/******************************************************************************
 * File:				category.change.php
 * Description:			changes two category IDs
 * Author:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2004-04-29
 * Last change:			2004-07-26
 * Copyright:           (c) 2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

if ($permission["editcateg"]) {
    print "<h2>".$PMF_LANG["ad_categ_paste"]."</h2>\n";
    $categoryToMove = $_POST["cat"];
    $categoryToRemove = $_POST["change"];
    $categoryTemp = rand(200000, 400000);
    
    $result_1 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET id = ".$categoryTemp." WHERE id = ".$categoryToRemove);
    $result_2 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET parent_id = ".$categoryTemp." WHERE parent_id = ".$categoryToRemove);
    $result_3 = $db->query("UPDATE ".SQLPREFIX."faqdata SET rubrik = ".$categoryTemp." WHERE rubrik = ".$categoryToRemove);
    $result_4 = $db->query("UPDATE ".SQLPREFIX."faqfragen SET ask_rubrik = ".$categoryTemp." WHERE ask_rubrik = ".$categoryToRemove);
    
    $result_5 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET id = ".$categoryToRemove." WHERE id = ".$categoryToMove);
    $result_6 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET parent_id = ".$categoryToRemove." WHERE parent_id = ".$categoryToMove);
    $result_7 = $db->query("UPDATE ".SQLPREFIX."faqdata SET rubrik = ".$categoryToRemove." WHERE rubrik = ".$categoryToMove);
    $result_8 = $db->query("UPDATE ".SQLPREFIX."faqfragen SET ask_rubrik = ".$categoryToRemove." WHERE ask_rubrik = ".$categoryToMove);
    
    $result_9 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET id = ".$categoryToMove." WHERE id = ".$categoryTemp);
    $result_10 = $db->query("UPDATE ".SQLPREFIX."faqcategories SET parent_id = ".$categoryToMove." WHERE parent_id = ".$categoryTemp);
    $result_11 = $db->query("UPDATE ".SQLPREFIX."faqdata SET rubrik = ".$categoryToMove." WHERE rubrik = ".$categoryTemp);
    $result_12 = $db->query("UPDATE ".SQLPREFIX."faqfragen SET ask_rubrik = ".$categoryToMove." WHERE ask_rubrik = ".$categoryTemp);
    
    if ($result_1 && $result_2 && $result_3 && $result_4 && $result_5 && $result_6 && $result_7 && $result_8 && $result_9 && $result_10 && $result_11 && $result_12) {
        print "<p>".$PMF_LANG["ad_categ_updated"]."</p>\n";
        }
    else {
        print "<p>".$PMF_LANG["ad_categ_paste_error"]."</p>\n";
        }
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=category\">".$PMF_LANG["ad_menu_categ_edit"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>