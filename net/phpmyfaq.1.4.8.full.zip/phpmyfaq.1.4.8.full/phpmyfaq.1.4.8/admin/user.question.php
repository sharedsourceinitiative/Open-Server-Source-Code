<?php
/******************************************************************************
 * File:				user.question.php
 * Description:			ask, if an user should be deleted
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-22
 * Last change:			2004-07-29
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/
if ($permission["deluser"]) {
	adminlog("Userdel, ".$id);
	list($user) = $db->fetch_row($db->query("SELECT NAME FROM ".SQLPREFIX."faquser WHERE ID='".$_REQUEST["id"]."'"));
?>
    <h2><?php print $PMF_LANG["ad_user"]; ?></h2>
	<form action="<?php print $_SERVER["PHP_SELF"].$linkext; ?>" method="post">
    <fieldset>
    <legend><?php print $PMF_LANG["ad_user_del_1"]; ?> <strong><?php print $user; ?></strong> <?php print $PMF_LANG["ad_user_del_2"]; ?></legend>
	<input type="hidden" name="aktion" value="deluser" />
	<input type="hidden" name="id" value="<?php print $_REQUEST["id"]; ?>" />
    <div align="center"><?php print $PMF_LANG["ad_user_del_3"]; ?><br /><input class="submit" type="submit" value="<?php print $PMF_LANG["ad_gen_yes"]; ?>" name="sicher" /> <input class="submit" type="submit" value="<?php print $PMF_LANG["ad_gen_no"]; ?>" name="sicher" /></div>
    </fieldset>
	</form>
<?php
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user\">".$PMF_LANG["ad_menu_user_administration"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>
