<?php
/******************************************************************************
 * File:				category.paste.php
 * Description:			pastes a category
 * Author:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-04-28
 * Last change:			2004-07-26
 * Copyright:           (c) 2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

if ($permission["editcateg"]) {
    print "<h2>".$PMF_LANG["ad_categ_paste"]."</h2>\n";
    $category = $_GET["cat"];
    $rootcat = $_GET["after"];
    
    $cat = new category;
    if ($category != $rootcat) {
        $result = $db->query("UPDATE ".SQLPREFIX."faqcategories SET parent_id = ".$rootcat." WHERE id = ".$category);
        print "<p>".$PMF_LANG["ad_categ_updated"]."</p>\n";
        }
    else {
        print "<p>".$PMF_LANG["ad_categ_paste_error"]."<br />".$db->error()."</p>\n";
        }
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=category\">".$PMF_LANG["ad_menu_categ_edit"]."</a></p>\n";
    }
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>