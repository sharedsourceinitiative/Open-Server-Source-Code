<?php
/******************************************************************************
 * File:				user.save.php
 * Description:			save an user
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-22
 * Last change:			2004-07-29
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

print "<h2>".$PMF_LANG["ad_menu_user_administration"]."</h2>\n";
if ($permission["edituser"]) {
	adminlog("Usersave, ".$_REQUEST["id"]);
	if (isset($_REQUEST["npass"])) {
		if ($_REQUEST["npass"] != $_REQUEST["nupass"]) {
			print "<p>".$PMF_LANG["ad_msg_passmatch"]."</p>";
			$error = 1;
			}
		}
	if (!isset($error)) {
        if (isset($_POST["right"]) && is_array($_POST["right"])) {
            $arrRights = $_POST["right"];
            }
        else {
            $arrRights = array(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);
            }
        
        $rights = "";
		$numRights = count($faqrights);
		for ($i = 0; $i < $numRights; $i++) {
			if (isset($arrRights[$i])) {
				$rights .= "1";
				}
			else {
				$rights .= "0";
				}
			}
        
		$query = "UPDATE ".SQLPREFIX."faquser SET ";
		
		if (isset($_REQUEST["npass"]) && $_REQUEST["npass"] != "") {
			$query .= "pass = MD5('".addslashes($_REQUEST["npass"])."'), ";
			}
		$query .= "name = '".addslashes($_REQUEST["name"])."', realname = '".$_REQUEST["realname"]."', email = '".$_REQUEST["email"]."', rights = '".addslashes($rights)."' WHERE id = '".$_REQUEST["id"]."'";
		
		if ($db->query($query)) {
			print "<p>".$PMF_LANG["ad_msg_savedsuc_1"]." <strong>".$_REQUEST["name"]."</strong> ".$PMF_LANG["ad_msg_savedsuc_2"]."</p>";
			}
		else {
			print "<p>".$PMF_LANG["ad_msg_mysqlerr"]."</p>";
			print "<p>PHP Errorlog: \"".$PHP_ERRORMSG."\"</p>";
			}
		}
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user\">".$PMF_LANG["ad_menu_user_administration"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>