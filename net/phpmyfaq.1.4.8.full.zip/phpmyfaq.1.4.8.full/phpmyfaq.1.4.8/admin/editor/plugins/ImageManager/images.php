<?php
/**
 * Show a list of images in a long horizontal table.
 * @author $Author: Wei Zhuo $
 * @version $Id: images.php 27 2004-04-01 08:31:57Z Wei Zhuo $
 * @package ImageManager
 */

error_reporting(E_ALL);

define("PMF_ROOT_DIR", dirname(dirname(dirname(dirname(dirname(__FILE__))))));

/* read configuration, include classes and functions */
require_once (PMF_ROOT_DIR."/inc/data.php");
require_once (PMF_ROOT_DIR."/inc/mysql.php");
define("SQLPREFIX", $DB["prefix"]);
$db = new DB();
$db->connect($DB["server"], $DB["user"], $DB["password"], $DB["db"]);
require_once (PMF_ROOT_DIR."/inc/config.php");
require_once (PMF_ROOT_DIR."/inc/constants.php");
require_once (PMF_ROOT_DIR."/inc/category.php");
require_once (PMF_ROOT_DIR."/inc/functions.php");
require_once (PMF_ROOT_DIR."/lang/language_en.php");

$user = "";
$pass = "";

if (isset($_REQUEST["uin"]) && $_REQUEST["uin"] != "") {
	$uin = str_replace("uin=", "", $_REQUEST["uin"]);
    $uin = str_replace("&aktion=editentry", "", $uin);
	}
if (isset($uin)) {
	$query = "SELECT usr, pass FROM ".SQLPREFIX."faqadminsessions WHERE UIN='".$uin."'";
	if (isset($PMF_CONF["ipcheck"])) {
		$query .= " AND ip = '".$_SERVER["REMOTE_ADDR"]."'";
		}
	list($user,$pass) = $db->fetch_row($db->query($query));
	$db->query("UPDATE ".SQLPREFIX."faqadminsessions SET time = '".time()."' WHERE uin = '".$uin."'");
	}

if (isset($user) && isset($pass)) {
	$result = $db->query("SELECT id, name, pass, rights FROM ".SQLPREFIX."faquser WHERE name = '".addslashes($user)."' AND pass = '".addslashes($pass)."'");
	if ($db->num_rows($result) > 0) {
		$auth = 1;
		}
	else {
		$auth = 0;
		}
	list($auth_user, $auth_name, $auth_pass, $auth_rights) = $db->fetch_row($result);
    $permission = @array_combine($faqrights, explode(",", substr(chunk_split($auth_rights,1,","), 0, -1)));
	}

if ($auth && $permission["addatt"]) {

require_once('config.inc.php');
require_once('Classes/ImageManager.php');

//default path is /
$relative = '/';
$manager = new ImageManager($IMConfig);

//process any file uploads
$manager->processUploads();

$manager->deleteFiles();

$refreshDir = false;
//process any directory functions
if($manager->deleteDirs() || $manager->processNewDir())
	$refreshDir = true;

//check for any sub-directory request
//check that the requested sub-directory exists
//and valid
if(isset($_REQUEST['dir']))
{
	$path = rawurldecode($_REQUEST['dir']);
	if($manager->validRelativePath($path))
		$relative = $path;
}


$manager = new ImageManager($IMConfig);


//get the list of files and directories
$list = $manager->getFiles($relative);


/* ================= OUTPUT/DRAW FUNCTIONS ======================= */

/**
 * Draw the files in an table.
 */
function drawFiles($list, &$manager)
{
	global $relative;
    

	foreach($list as $entry => $file) 
	{ ?>
		<td><table width="100" cellpadding="0" cellspacing="0"><tr><td class="block">
		<a href="javascript:;" onclick="selectImage('<?php print $file['relative'];?>', '<?php print $entry; ?>', <?php print $file['image'][0];?>, <?php print $file['image'][1]; ?>);"title="<?php print $entry; ?> - <?php print Files::formatSize($file['stat']['size']); ?>"><img src="<?php print $manager->getThumbnail(trim($file['relative'])); ?>" alt="<?php print $entry; ?> - <?php print Files::formatSize($file['stat']['size']); ?>"/></a>
		</td></tr><tr><td class="edit">
			<a href="images.php?uin=<?php print $_REQUEST["uin"]; ?>&amp;dir=<?php print $relative; ?>&amp;delf=<?php print rawurlencode($file['relative']);?>" title="Trash" onclick="return confirmDeleteFile('<?php print $entry; ?>');"><img src="img/edit_trash.gif" height="15" width="15" alt="Trash"/></a>
		<? if($file['image']){ echo $file['image'][0].'x'.$file['image'][1]; } else echo $entry;?>
		</td></tr></table></td> 
	  <? 
	}//foreach
}//function drawFiles


/**
 * Draw the directory.
 */
function drawDirs($list, &$manager) 
{
	global $relative;

	foreach($list as $path => $dir) 
	{ ?>
		<td><table width="100" cellpadding="0" cellspacing="0"><tr><td class="block">
		<a href="images.php?uin=<?php print $_REQUEST["uin"]; ?>&amp;dir=<?php print rawurlencode($path); ?>" onclick="updateDir('<?php print $path; ?>')" title="<?php print $dir['entry']; ?>"><img src="img/folder.gif" height="80" width="80" alt="<?php print $dir['entry']; ?>" /></a>
		</td></tr><tr>
		<td class="edit">
			<a href="images.php?uin=<?php print $_REQUEST["uin"]; ?>&amp;dir=<?php print $relative; ?>&amp;deld=<?php print rawurlencode($path); ?>" title="Trash" onclick="return confirmDeleteDir('<?php print $dir['entry']; ?>', <?php print $dir['count']; ?>);"><img src="img/edit_trash.gif" height="15" width="15" alt="Trash"/></a>
			<?php print $dir['entry']; ?>
		</td>
		</tr></table></td>
	  <? 
	} //foreach
}//function drawDirs


/**
 * No directories and no files.
 */
function drawNoResults() 
{
?>
<table width="100%">
  <tr>
    <td class="noResult">No Images Found</td>
  </tr>
</table>
<?	
}

/**
 * No directories and no files.
 */
function drawErrorBase(&$manager) 
{
?>
<table width="100%">
  <tr>
    <td class="error">Invalid base directory: <?php print $manager->config['base_dir']; ?></td>
  </tr>
</table>
<?	
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
	<title>Image List</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="assets/imagelist.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="assets/dialog.js"></script>
<script type="text/javascript">
/*<![CDATA[*/

	if(window.top)
		I18N = window.top.I18N;

	function hideMessage()
	{
		var topDoc = window.top.document;
		var messages = topDoc.getElementById('messages');
		if(messages)
			messages.style.display = "none";
	}

	init = function()
	{
		hideMessage();
		var topDoc = window.top.document;

<? 
	//we need to refesh the drop directory list
	//save the current dir, delete all select options
	//add the new list, re-select the saved dir.
	if($refreshDir) 
	{ 
		$dirs = $manager->getDirs();
?>
		var selection = topDoc.getElementById('dirPath');
		var currentDir = selection.options[selection.selectedIndex].text;

		while(selection.length > 0)
		{	selection.remove(0); }
		
		selection.options[selection.length] = new Option("/","<?php print rawurlencode('/'); ?>");	
		<? foreach($dirs as $relative=>$fullpath) { ?>
		selection.options[selection.length] = new Option("<?php print $relative; ?>","<?php print rawurlencode($relative); ?>");		
		<? } ?>
		
		for(var i = 0; i < selection.length; i++)
		{
			var thisDir = selection.options[i].text;
			if(thisDir == currentDir)
			{
				selection.selectedIndex = i;
				break;
			}
		}		
<? } ?>
	}	

	function editImage(image) 
	{
		var url = "editor.php?img="+image;
		Dialog(url, function(param) 
		{
			if (!param) // user must have pressed Cancel
				return false;
			else
			{
				return true;
			}
		}, null);		
	}

/*]]>*/
</script>
<script type="text/javascript" src="assets/images.js"></script>
</head>

<body>
<? if ($manager->isValidBase() == false) { drawErrorBase($manager); } 
	elseif(count($list[0]) > 0 || count($list[1]) > 0) { ?>
<table>
	<tr>
	<? drawDirs($list[0], $manager); ?>
	<? drawFiles($list[1], $manager); ?>
	</tr>
</table>
<? } else { drawNoResults(); } ?>
</body>
</html>
<?php
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>
