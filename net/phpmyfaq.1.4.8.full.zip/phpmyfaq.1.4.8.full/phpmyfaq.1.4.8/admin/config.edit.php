<?php
/******************************************************************************
 * File:				config.edit.php
 * Description:			edit the configuration
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-24
 * Last change:			2004-09-19
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/
if ($permission["editconfig"]) {
?>
	<h2><?php print $PMF_LANG["ad_config_edit"]; ?></h2>
	<form action="<?php print $_SERVER["PHP_SELF"].$linkext; ?>" method="post">
	<input type="hidden" name="aktion" value="saveconfig" />
<?php
    foreach ($LANG_CONF as $key => $value) {
?>
    <dl>
    <dt><strong><?php print $value[1]; ?></strong></dt>
    <dd><?php
		if ($value[0] == "area") {
			print "<textarea class=\"admin\" name=\"edit[".$key."]\" cols=\"50\" rows=\"6\" style=\"width: 400px;\">".$PMF_CONF[$key]."</textarea>";
			}
		elseif ($value[0] == "input") {
			print "<input class=\"admin\" type=\"text\" name=\"edit[".$key."]\" size=\"64\" style=\"width: 400px;\" value=\"".$PMF_CONF[$key]."\" />";
			}
		elseif ($value[0] == "select") {
			print "\t\t<select name=\"edit[".$key."]\" size=\"1\">\n";
        	if ($dir = @opendir(PMF_ROOT_DIR."/lang")) {
        		while ($dat = @readdir($dir)) {
        			if (substr($dat, -4) == ".php") {
        				print "\t\t<option value=\"".$dat."\"";
        				if ($dat == $PMF_CONF["language"]) {
        					print " selected=\"selected\"";
        					}
                        print ">".$languageCodes[substr(strtoupper($dat), 9, 2)]."</option>\n";
        				}
        			}
        		}
        	else {
        		print "\t\t<option>English</option>";
        		}
			print "\t\t</select>\n";
			}
		elseif ($value[0] == "checkbox") {
			print "<input type=\"checkbox\" name=\"edit[".$key."]\" value=\"TRUE\"";
			if (isset($PMF_CONF[$key])) {
				print " checked=\"checked\"";
				}
			print " /> ".strtolower($PMF_LANG["ad_entry_active"]);
			}
		elseif ($value[0] == "print") {
			print $PMF_CONF[$key];
			print "<input type=\"hidden\" name=\"edit[".$key."]\" size=\"64\" value=\"".$PMF_CONF[$key]."\" />";
			}
?></dd>
    </dl>
<?php
        }
?>
    <p><input class="submit" type="submit" value="<?php print $PMF_LANG["ad_config_save"]; ?>" /> <input class="submit" type="reset" value="<?php print $PMF_LANG["ad_config_reset"]; ?>" /></p>
    </form>
<?php
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>