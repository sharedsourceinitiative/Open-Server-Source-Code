<?php
/******************************************************************************
 * File:				user.list.php
 * Description:			show all users
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-21
 * Last change:			2004-08-21
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/
if (($permission["edituser"] || $permission["deluser"] || $permission["adduser"])) {
    $perpage = 20;
    $pages = 1;
    if (!isset($_GET["pages"])) {
		$pages = ceil($db->num_rows($db->query("SELECT id FROM ".SQLPREFIX."faquser")) / $perpage);
		if ($pages < 1) {
			$pages = 1;
			}
		}
	else {
		$pages = $_GET["pages"];
		}
	if (!isset($_GET["page"])) {
		$page = 1;
		}
	else {
		$page = $_GET["page"];
		}
	$start = ($page - 1) * $perpage;
	$ende = $perpage;
?>
    <h2><?php print $PMF_LANG["ad_user"]; ?></h2>
    <table class="list">
    <thead>
        <tr>
            <th class="list"><?php print $PMF_LANG["ad_user_username"]; ?></th>
            <th class="list"><?php print $PMF_LANG["ad_user_rights"]; ?></th>
            <th class="list"><?php print $PMF_LANG["ad_user_action"]; ?></th>
        </tr>
    </thead>
<?php
		if ($pages > 1) {
?>
    <tfoot>
        <tr>
		    <td colspan="4"><?php print PageSpan("<a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user&amp;page=<NUM>&amp;pages=".$pages."\">", 1, $pages, $page); ?></td>
        </tr>
    </tfoot>
<?php
			}
?>
    <tbody>
<?php
		$result = $db->query("SELECT id, name, realname, rights FROM ".SQLPREFIX."faquser ORDER BY id LIMIT ".$start.", ".$perpage);
		while ($row = $db->fetch_object($result)) {
?>
        <tr>
    		<td class="list"><?php print $row->name; if (is_string($row->realname)) { print " (".$row->realname.")"; } ?></td>
    		<td class="list"><?php print $row->rights; ?></td>
    		<td class="list"><a href="<?php print $_SERVER["PHP_SELF"].$linkext; ?>&amp;aktion=useredit&amp;id=<?php print $row->id; ?>" title="<?php print $PMF_LANG["ad_user_edit"]; ?>"><img src="images/edit.gif" width="18" height="18" alt="<?php print  $PMF_LANG["ad_user_edit"]; ?>" border="0" /></a><?php if (strtolower($row->name) != "admin") { ?>&nbsp;&nbsp;<a href="<?php print $_SERVER["PHP_SELF"].$linkext; ?>&amp;aktion=userdel&amp;id=<?php print $row->id; ?>" title="<?php print $PMF_LANG["ad_user_delete"]; ?>"><img src="images/delete.gif" width="17" height="18" alt="<?php print $PMF_LANG["ad_user_delete"]; ?>" border="0" /></a><?php } ?></td>
    	</tr>
<?php
			}
?>
	</tbody>
    </table>
    <p>[ <a href="<?php print $_SERVER["PHP_SELF"].$linkext; ?>&amp;aktion=useradd"><?php print $PMF_LANG["ad_user_add"]; ?></a> ]</p>
<?php
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>
