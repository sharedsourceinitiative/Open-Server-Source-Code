<?php
/******************************************************************************
 * File:				user.addsave.php
 * Description:			save an user
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-23
 * Last change:			2003-07-27
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

print "<h2>".$PMF_LANG["ad_menu_user_administration"]."</h2>\n";
if ($permission["adduser"]) {
	if ($db->num_rows($db->query("SELECT ID FROM ".SQLPREFIX."faquser WHERE NAME='".addslashes($_REQUEST["name"])."'")) < 1) {
		if ($db->query("INSERT INTO ".SQLPREFIX."faquser (name, realname, email, pass, rights) VALUES ('".$_REQUEST["name"]."', '".addslashes($_REQUEST["realname"])."', '".$_REQUEST["email"]."', MD5('".addslashes($_REQUEST["npass"])."'), '".str_repeat("0", count($faqrights))."')")) {
			list($id) = $db->fetch_row($db->query("SELECT id FROM ".SQLPREFIX."faquser WHERE name = '".addslashes($_REQUEST["name"])."' AND pass = MD5('".addslashes($_REQUEST["npass"])."')"));
			print "<p>".$PMF_LANG["ad_adus_suc"]."</p>\n";
            print "<p><a href=\"".$_SERVER["PHP_SELF"].$linkext."&aktion=useredit&id=".$id."\">".$PMF_LANG["ad_adus_edit"]."</a></p>\n";
			}
		else {
			print "<p>".$PMF_LANG["ad_adus_dberr"]."</p>\n";
			}
		}
	else {
		print "<p>".$PMF_LANG["ad_adus_exerr"]."</p>\n";
		}
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user\">".$PMF_LANG["ad_menu_user_administration"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>