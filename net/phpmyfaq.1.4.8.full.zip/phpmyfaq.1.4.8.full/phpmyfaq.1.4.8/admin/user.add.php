<?php
/******************************************************************************
 * File:				user.add.php
 * Description:			form to add an user
 * Authors:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-02-23
 * Last change:			2004-07-29
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/
if ($permission["adduser"]) {
?>
	<h2><?php print $PMF_LANG["ad_menu_user_administration"]; ?></h2>
	<form action="<?php print $_SERVER["PHP_SELF"].$linkext; ?>" method="POST">
    <fieldset>
    <legend><?php print $PMF_LANG["ad_adus_adduser"]; ?></legend>
	<input type="hidden" name="aktion" value="addsave" />
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_adus_name"]; ?></strong></span>
    <input class="admin" type="text" name="name" style="width: 200px;" /></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_user_realname"]; ?></strong></span>
    <input class="admin" type="text" style="width: 200px;" name="realname" /></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_entry_email"]; ?></strong></span>
    <input class="admin" type="text" style="width: 200px;" name="email" /></div>
	<div class="row"><span class="label"><strong><?php print $PMF_LANG["ad_adus_password"]; ?></strong></span>
    <input class="admin" type="password" name="npass" style="width: 200px;" /></div>
	<div class="row"><span class="label"><strong>&nbsp;</strong></span>
    <input class="submit" type=submit value="<?php print $PMF_LANG["ad_adus_add"]; ?>" /></div>
    </fieldset>
	</form>
<?php
    print "<p><img src=\"images/arrow.gif\" width=\"11\" height=\"11\" alt=\"\" border=\"0\"> <a href=\"".$_SERVER["PHP_SELF"].$linkext."&amp;aktion=user\">".$PMF_LANG["ad_menu_user_administration"]."</a></p>\n";
	}
else {
	print $PMF_LANG["err_NotAuth"];
	}
?>
