/******************************************************************************
 * Datei:				functions.js
 * Autor:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Datum:				2003-11-13
 * Letzte �nderung:		2004-07-07
 * Copyright:           (c) 2001-2004 phpMyFAQ Team
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

function printarticle(id, lang)
{
	Fenster = window.open("printing.php?id=" + id + "&lang=" + lang, "Fenster", "width=720, height=450, resizable=yes, menubar=no, scrollbars=yes");
	Fenster.moveTo(50,50);
	Fenster.focus();
}

function Picture(pic,title,width,height)
{
    popup = window.open(pic, title, 'width='+width+', height='+height+', toolbar=no, directories=no, status=no, scrollbars=no, resizable=yes, menubar=no');
    popup.focus();
}

function checkAll(checkBox)
{
    var v = checkBox.checked;
    var f = checkBox.form;
    for (var i = 0; i < f.elements.length; i++) {
        if (f.elements[i].type == "checkbox") {
            f.elements[i].checked = v;
            }
        }
}