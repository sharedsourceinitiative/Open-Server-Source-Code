<?php
/******************************************************************************
 * File:				category.php
 * Description:		    category class
 * Author:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2004-02-16
 * Last Update:		    2004-11-13
 * Copyright:           (c) 2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

class Category
{
    var $categories = array();
    var $categoryName = array();
    var $catTree = array();
    var $lineTab;
    var $treeTab;
    var $symbols;
    var $id, $lang, $name, $parent_id, $level, $description;
	
    /* PHP4 constructor */
    function Category ()
    {
        $this->__construct();
    }
    
    /* PHP5 constructor */
	function __construct()
    {
        $this->symbols = array("vert" => "|", "plus" => "+;", "minus" => "-", "vide" => "&nbsp;", "angle" => "-", "milieu" => "|-");
        $this->id = "id";
        $this->lang = "lang";
        $this->name = "name";
        $this->parent_id = "parent_id";
        $this->description = "description";
        $this->level = "level";
        
        $tab = $this->getOrderedCategories();
        
        for ($i = 0; $i < count($tab); $i++) {
            $this->lineTab[$i] = array (
                                    $this->id => $tab[$i][$this->id],
                                    $this->lang => $tab[$i][$this->lang],
                                    $this->name => $tab[$i][$this->name],
                                    $this->parent_id => $tab[$i][$this->parent_id],
                                    $this->description => $tab[$i][$this->description]);
            }
        for ($i = 0; $i < count($tab); $i++) {
			$this->lineTab[$i][$this->level] = $this->levelOf($this->lineTab[$i][$this->id]);
            }
    }
    
    /* get all categories and write them in an array with ordered IDs */
    function getOrderedCategories()
    {
        global $db;
        $query = "SELECT id, lang, parent_id, name, description FROM ".SQLPREFIX."faqcategories ORDER BY id";
        $result = $db->query($query);
        while ($row = $db->fetch_assoc($result)) {
            $this->categories[] = $row;
            $this->categoryName[$row["id"]] = $row;
            }
        return $this->categories;
    }
    
    /* get main categories and write them in an array */
    function getCategories($cat)
    {
        global $db;
        $query = "SELECT id, lang, parent_id, name, description FROM ".SQLPREFIX."faqcategories WHERE parent_id = 0";
        foreach (explode(";", $cat) as $cats) {
            $query .= " OR parent_id = ".$cats;
            }
        $query .= " ORDER BY id";
        $result = $db->query($query);
        while ($row = $db->fetch_assoc($result)) {
            $this->categories[] = $row;
            }
        return $this->categories;
    }
    
    /* get all categories and write them in an array with correct IDs */
    function getAllCategories()
    {
        global $db;
        $query = "SELECT id, lang, parent_id, name, description FROM ".SQLPREFIX."faqcategories";
        $result = $db->query($query);
        while ($row = $db->fetch_assoc($result)) {
            $this->categories[$row["id"]] = $row;
            }
        return $this->categories;
    }
    
    /* buld the tree in an array */
    function buildTree($id_parent = 0, $indent = 0)
    {
        $tt = array();
        $x = 0;
        $loop = 0;
        foreach ($this->categories as $n) {
            if ($n["parent_id"] == $id_parent) {
                $tt[$x++] = $loop;
                }
            $loop++;
            }
        if ($x != 0) {
            foreach ($tt as $d) {
                $tmp = array();
                foreach ($this->categories[$d] as $key => $value) {
                    $tmp[$key] = $value; 
                    }
                $tmp["indent"] = $indent;
                $this->catTree[] = $tmp;
                $this->buildTree($tmp["id"], $indent+1);
                }
            }
        else {
            return 0;
            }
    }
    
    /* get the level of the item id */
	function levelOf($id)
    {
		$ret = 0;
		while ($this->lineTab[$this->getLine($id)][$this->parent_id] != 0) {
            $ret++;
			$id = $this->lineTab[$this->getLine($id)][$this->parent_id];
            }
        return $ret;
    }
    
	// Get the line number where to find the node $id 
	function getLine($id)
    {
        for ($i = 0; $i < count($this->lineTab); $i++) {
            if ($this->lineTab[$i][$this->id] == $id) {
                return $i;
                }
            }
	}
    
	// transform the linear array in a 1D array in the order of the tree, with the info
	function transform($id)
    {
		$line = $this->getLine($id);
		$tabs = $this->getChilds($id);
		$num = count($tabs);
		
        if ($id > 0) {
		    $thisLevel = $this->lineTab[$line][$this->level];
            $thisParent_id = $this->lineTab[$line][$this->parent_id];
		    $thisName = $this->lineTab[$line][$this->name];
            $thisdescription = $this->lineTab[$line][$this->description];
            }
	    
		if ($num > 0) {
			$symbol = "minus";
            }
		else {
            if (isset($thisParent_id)) {
                $temp = $this->getChilds($thisParent_id);
            } else {
                $temp = 1;
                }
			$symbol = ($id == $temp[count($temp)-1]) ? "angle" : "milieu";
		    }
		
        $ascendants = $this->getNodes($id);
        $arbre = array();
		for ($i = 0; $i < count($ascendants); $i++) {
			$freres = $this->getBrothers($ascendants[$i]);
			$arbre[$i] = ($ascendants[$i] == $freres[count($freres)-1]) ? "vide" : "vert";
            }
        
		if ($id > 0) {
            $this->treeTab[] = array("id" => $id, "symbol" => $symbol, "name" => $thisName, "numChilds" => count($tabs), "level" => $thisLevel, "parent_id" => $thisParent_id, "childs" => $tabs, "tree" => $arbre, "description" => $thisdescription);
            }
        
		for ($i = 0; $i < count($tabs); $i++) {
			$this->transform($tabs[$i]);
            }
	}
    
	// get the id of the parent_id, i.e. where parent_id == 0
	function getParent_id()
    {
		for ($i = 0; $i < count($this->lineTab); $i++) {
			if ($this->lineTab[$i][$this->parent_id] == 0) {
				return $this->lineTab[$i][$this->id];
                }
            }
	}
	
	// get the line number where to find the node $id in the category tree 
	function getLineCategory($id)
    {
        for ($i = 0; $i < count($this->treeTab); $i++) {
			if ($this->treeTab[$i]["id"] == $id) {
                return $i;
                }
            }
	}
	
	// list in a array of the $id of the child
	function getChilds($id)
    {
		$ret = array();
		for ($i = 0; $i < count($this->lineTab); $i++) {
			if ($this->lineTab[$i][$this->parent_id] == $id) {
				$ret[] = $this->lineTab[$i][$this->id];
                }
            }
		return $ret;
	}
	
	// number of childs of the $id 
	function numChilds($id)
    {
		return count($this->getNodes($id));
	}
	
	// list in array the root, super-root, ... of the $id 
	function getNodes($id)
    {
        if ($id > 0) {
            $thisLevel = $this->lineTab[$this->getLine($id)][$this->level];
            $temp = array();
    		for ($i = $thisLevel; $i > 0; $i--) {
                $id = $this->lineTab[$this->getLine($id)][$this->parent_id];
                $temp[$i-1] = $id;
                }
            $ret = array();
            $num = count($temp);
            for ($i = 0; $i < $num; $i++) {
    			$ret[$i] = $temp[$i];
                }
            return $ret;
            }
	}
	
	// collapse the node $id
	function collapse($id)
    {
		$this->treeTab[$this->getLineCategory($id)]["symbol"] = "plus";
	}
	
	// collapse the complete category tree
	function collapseAll()
    {
		for ($i = 0; $i < count($this->treeTab); $i++) {
			if ($this->treeTab[$i]["symbol"] == "minus") {
				$this->treeTab[$i]["symbol"] = "plus";
                }
            }
	}
    
	// expand the node $id
	function expand($id)
    {
		$this->treeTab[$this->getLineCategory($id)]["symbol"] = "minus";
	}
	
	// try to expand from the parent_id to the node $id
	function expandTo($id)
    {
		$this->collapseAll();
		$ascendants = $this->getNodes($id);
		$ascendants[] = $id;
		for ($i = 0; $i < count($ascendants); $i++) {
			$numChilds = $this->treeTab[$this->getLineCategory($ascendants[$i])]["numChilds"];
			if ($numChilds > 0) {
				$this->expand($ascendants[$i]);
                }
			else {
				$i = count($ascendants);
                }
		    }
	}
	
	// expand the entire tree
	function expandAll()
    {
		for ($i = 0; $i < count($this->treeTab); $i++) {
			if ($this->treeTab[$i]["symbol"] == "plus") {
				$this->treeTab[$i]["symbol"] = "minus";
                }
            }
	}
	

	// width of the expanded tree
	function width()
    {
		for ($x = -1, $i = 0; $i < count($this->treeTab) ; $i = $this->getNextLineTree($i)) {
			$x = max($x,$this->treeTab[$i]["level"]);
            }
		return $x;
	}

	// total height of the expanded tree	
	function height()
    {
		return count($this->treeTab);
	}

	/**
    * print the static tree with the number of records
    *
    * @return   string
    * @access   public
    * @author   Thorsten Rinne <thorsten@phpmyfaq.de>
    */
	function viewTree()
    {
        global $sids, $db, $PMF_LANG;
        $result = $db->query("SELECT rubrik, count(rubrik) AS number FROM ".SQLPREFIX."faqdata WHERE active = 'yes' GROUP BY rubrik");
	    if ($db->num_rows($result) > 0) {
		    while ($row = $db->fetch_object($result)) {
                $number[$row->rubrik] = $row->number;
            }
        }
        $output = "<ul>\n";
        $open = 0;
		$this->expandAll();
        
        for ($y = 0 ;$y < $this->height(); $y = $this->getNextLineTree($y)) {
            
            list($symbol, $categoryName, $parent, $description) = $this->getLineDisplay($y);
            
            $level = $this->treeTab[$y]["level"];
            $leveldiff = $open - $level;
            
            if ($leveldiff > 1) {
                
                for ($i = $leveldiff; $i > 1; $i--) {
                    
                    $output .= "</li>\n".str_repeat("\t", $level+2)."</ul>\n".str_repeat("\t", $level+1)."</li>\n";
                    
                }
            }
            
            if (!isset($number[$parent])) {
                $number[$parent] = 0;
            }
            
            if ($level < $open) {
                
                $output .= "</li>\n".str_repeat("\t", $level+2)."</ul>\n".str_repeat("\t", $level+1)."</li>\n";
                
            } elseif ($level == $open && $y != 0) {
                
                $output .= "</li>\n";
                
            }
            
            if ($level > $open) {
                
                $output .= "\n".str_repeat("\t", $level+1)."<ul>\n".str_repeat("\t", $level+1)."<li>";
                
            } else {
                
                $output .= str_repeat("\t", $this->treeTab[$y]["level"]+1)."<li>";
                
            }
            
    		if ($this->treeTab[$y]["symbol"] == "minus") {
    			$output .= "<a title=\"".$description."\" href=\"".$_SERVER["PHP_SELF"]."?".$sids."action=show&amp;cat=".$parent."\">".$categoryName."</a> (".$number[$parent]." ".$PMF_LANG["msgEntries"].")";
            } else {
    			$output .= "<a title=\"".$description."\" href=\"".$_SERVER["PHP_SELF"]."?".$sids."action=show&amp;cat=".$parent."\">".$categoryName."</a> (".$number[$parent]." ".$PMF_LANG["msgEntries"].")";
            }
            
            $open = $level;
            
        }
        
        if ($level > 0) {
            $output .= str_repeat("</li>\n\t</ul>\n\t", $level);
        }
        
        $output .= "\t</li>\n";
        $output .= "\t</ul>\n";
        return $output;
	}

    // return the three parts of a line to display: last part of tree, category name, and id of the root node
	function getLineDisplay($y)
    {
		$ret[0] = $this->symbols[$this->treeTab[$y]["symbol"]];
		$ret[1] = $this->treeTab[$y]["name"];
		$ret[2] = $this->treeTab[$y]["id"];
        $ret[3] = $this->treeTab[$y]["description"];
		return $ret;
	}

    // get the next line in the array treeTab, depending of the collapse/expand node	
	function getNextLineTree($l)
    {
		if ($this->treeTab[$l]["symbol"] != "plus") {
			return $l + 1;
            }
		else {
			for ($i=$l+1;$i<$this->height();$i++) {
				if ($this->treeTab[$i]["level"]<=$this->treeTab[$l]["level"]) {
					return $i;
                    }
                }
            }
		return $this->height();
	}

	// get the list of the brothers of $id (include $id)
	function getBrothers($id)
    {
		$thisParent_id = $this->lineTab[$this->getLine($id)][$this->parent_id];
        $ret = $this->getChilds($thisParent_id);
		return $ret;
	}
	
    /* gets all categories in <option> tags */
    function printCategoryOptions($catID = "")
    {
        $categories = "";
        foreach ($this->catTree as $cat) {
            $indent = "";
            for ($i = 0; $i < $cat["indent"]; $i++) {
                $indent .= "....";
                }
            $categories .= "\t<option value=\"".$cat["id"]."\"";
			if ($catID == $cat["id"]) {
				$categories .= " selected=\"selected\"";
				}
            $categories .= ">";
            $categories .= $indent.$cat["name"]." (".$cat["lang"].")</option>\n";
            }
        return $categories;
    }
    
    /**
    * Displays the main navigation
    *
    * @param    int
    * @return   string
    * @access   public
    * @author   Thorsten Rinne <thorsten@phpmyfaq.de>
    */
    function printCategories($activeCat = 0)
    {
        global $sids, $PMF_LANG;
        $open = 0;
        $output = "";
        if ($this->height() > 0) {
            
            for ($y = 0 ;$y < $this->height(); $y = $this->getNextLineTree($y)) {
                
                list($symbol, $categoryName, $parent, $description) = $this->getLineDisplay($y);
                
                if ($activeCat == $parent) {
                    $a = " class=\"active\"";
                } else {
                    $a = "";
                }
                
                $level = $this->treeTab[$y]["level"];
                $leveldiff = $open - $level;
                
                if ($leveldiff > 1) {
                    
                    for ($i = $leveldiff; $i > 1; $i--) {
                        
                        $output .= "</li>\n".str_repeat("\t", $level+2)."</ul>\n".str_repeat("\t", $level+1)."</li>\n";
                        
                    }
                }
                
                if ($level < $open) {
                    
                    $output .= "</li>\n".str_repeat("\t", $level+2)."</ul>\n".str_repeat("\t", $level+1)."</li>\n";
                    
                } elseif ($level == $open && $y != 0) {
                    
                    $output .= "</li>\n";
                    
                }
                
                if ($level > $open) {
                    
                    $output .= "\n".str_repeat("\t", $level+1)."<ul>\n".str_repeat("\t", $level+1)."<li>";
                    
                } else {
                    
                    $output .= str_repeat("\t", $this->treeTab[$y]["level"]+1)."<li>";
                    
                }
                
                if ($this->treeTab[$y]["symbol"] == "plus") {
            		$output .= "<a title=\"".$description."\" href=\"".$_SERVER["PHP_SELF"]."?".$sids."action=show&amp;cat=".$parent."\"".$a.">".$categoryName." <img src=\"images/more.gif\" width=\"11\" height=\"11\" alt=\"".$categoryName."\" style=\"border: none; vertical-align: middle;\" /></a>";
                } else {
                    
            		if ($this->treeTab[$y]["symbol"] == "minus") {
                        
            			$output .= "<a title=\"".$description."\" href=\"".$_SERVER["PHP_SELF"]."?".$sids."action=show&amp;cat=".$this->treeTab[$y]["parent_id"]."\"".$a.">".$categoryName."</a>";
                        
                    } else {
                        
            			$output .= "<a title=\"".$description."\" href=\"".$_SERVER["PHP_SELF"]."?".$sids."action=show&amp;cat=".$parent."\"".$a.">".$categoryName."</a>";
                        
                    }
                
                }
                
                $open = $level;
                
            }
            if ($open > 0) {
                
                $output .= str_repeat("</li>\n\t</ul>\n\t", $open);
                
            }
            
            $output .= "</li>";
            return $output;
            
        } else {
            
            $output = "<li>".$PMF_LANG["no_cats"]."</li>\n";
            
        }
        
        return $output;
    }
    
    /* checks if a category is a child node */
    function isChild($catID, $rootCatID)
    {
        // FIXME: rewrite without using the database
        global $db;
        $query = "SELECT parent_id FROM ".SQLPREFIX."faqcategories WHERE id = ".$rootCatID;
        $result = $db->query($query);
        while ($row = $db->fetch_object($result)) {
            if ($row->parent_id == $catID) {
                return FALSE;
                }
            else {
                return TRUE;
                }
            }
        return FALSE;
    }
    
    /* gets the path from root to child */
	function getPath($id, $separator = " &raquo; ")
    {
        $ids = $this->getNodes($id);
        $num = count($ids);
        for ($i = 0; $i < $num; $i++) {
            $temp[] = $this->treeTab[$this->getLineCategory($ids[$i])]["name"];
            }
        $temp[] = $this->treeTab[$this->getLineCategory($id)]["name"];
        return implode($separator, $temp);
	}
    
    /* destructor */
    function __destruct()
    {
    
    }
}
?>