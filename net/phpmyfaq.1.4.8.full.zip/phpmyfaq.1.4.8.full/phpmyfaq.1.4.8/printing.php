<?php
/******************************************************************************
 * Datei:				printing.php
 * Autoren:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Datum:				2002-08-29
 * Letzte �nderung:		2004-09-05
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 ******************************************************************************/

require_once ("inc/data.php");
require_once ("inc/mysql.php");
require_once ("inc/functions.php");
require_once ("inc/config.php");
require_once ("inc/category.php");

define("SQLPREFIX", $DB["prefix"]);
$db = new DB();
$db->connect($DB["server"], $DB["user"], $DB["password"], $DB["db"]);

if (isset($_GET["lang"]) && $_GET["lang"] != "" && strlen($_GET["lang"]) <= 2 && !preg_match("=/=", $_GET["lang"])) {
    if (@is_file("lang/language_".$_REQUEST["lang"].".php")) {
        require_once("lang/language_".$_REQUEST["lang"].".php");
        $LANGCODE = $_REQUEST["lang"];
    } else {
        unset($LANGCODE);
    }
}

if (!isset($LANGCODE) && isset($_COOKIE["lang"]) && $_COOKIE["lang"] != "" && strlen($_COOKIE["lang"]) <= 2 && !preg_match("=/=", $_COOKIE["lang"])) {
    if (@is_file("lang/language_".$_COOKIE["lang"].".php")) {
        require_once("lang/language_".$_COOKIE["lang"].".php");
        $LANGCODE = $_COOKIE["lang"];
    } else {
        unset($LANGCODE);
    }
}

if (!isset($LANGCODE) && isset($PMF_CONF["detection"]) && isset($_SERVER["HTTP_ACCEPT_LANGUAGE"])) {
    if (@is_file("lang/language_".substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0, 2).".php")) {
        require_once("lang/language_".substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0, 2).".php");
        $LANGCODE = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"], 0, 2);
        @setcookie("lang", $LANGCODE, time()+3600);
    } else {
        unset($LANGCODE);
    }
} elseif (!isset($PMF_CONF["detection"])) {
    if (@require_once("lang/".$PMF_CONF["language"])) {
        $LANGCODE = $PMF_LANG["metaLanguage"];
        @setcookie("lang", $LANGCODE, time()+3600);
    } else {
        unset($LANGCODE);
    }
}

if (isset($LANGCODE)) {
    require_once("lang/language_".$LANGCODE.".php");
} else {
    $LANGCODE = "en";
    require_once ("lang/language_en.php");
}

if (isset($_GET["id"]) && checkIntVar($_GET["id"]) == TRUE) {
	$id = $_GET["id"];
	}
if (isset($_GET["lang"]) && strlen($_GET["lang"]) <= 2 && !preg_match("=/=", $_GET["lang"])) {
    $lang = $_GET["lang"];
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $PMF_LANG["metaLanguage"]; ?>" lang="<?php print $PMF_LANG["metaLanguage"]; ?>">
<head>
	<title><?php print $PMF_CONF["title"]; ?>: <?php print $PMF_LANG["msgPrinterFriendly"]; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=<?php print $PMF_LANG["metaCharset"]; ?>" />
	<style type="text/css" media="screen">
	body {
		background-color: #ffffff;
		margin: 10px;
	}
	#header {
		font: 24px Verdana, Geneva, Arial, Helvetica, sans-serif;
		background: #F8F8FF;
		border-bottom: 1px solid Black;
		border-top: 1px solid Black;
		text-align: center;
	}
	#article {
		font: 12px Verdana, Geneva, Arial, Helvetica, sans-serif;
		padding: 5px;
	}
	#links { }
	#footer { }
	#close {
		font: 12px Verdana, Geneva, Arial, Helvetica, sans-serif;
		text-align: center;
		border: 1px double Black;
		padding: 3px;
		margin-left: 40%;
		margin-right: 40%;
	}
</style>
</head>
<body>
<?php
$output = "";
$result = $db->query("SELECT id, rubrik, thema, content, datum FROM ".SQLPREFIX."faqdata WHERE id = '".$id."' AND lang = '".$lang."' AND active = 'yes'");
if ($db->num_rows($result) > 0) {
	while ($row = $db->fetch_object($result)) {
		logViews($id, $lang);
        $tree = new Category();
?>
<h1 id="header"><?php print $tree->categoryName[$row->rubrik]["name"]; ?>: <em><?php print stripslashes($row->thema); ?></em></h1>

<p id="article"><?php print stripslashes($row->content); ?></p>

<p id="links"><?php print $PMF_LANG["msgLastUpdateArticle"].makeDate($row->datum); ?><br />URL: <a href="http://<?php print $_SERVER["HTTP_HOST"].str_replace("printing.php", "index.php?action=artikel&cat=".$row->rubrik."&id=".$id."&artlang=".$lang, $_SERVER["PHP_SELF"]); ?>" target="_blank"><?php print $_SERVER["HTTP_HOST"].str_replace("printing.php", "index.php?action=artikel&cat=".$row->rubrik."&id=".$id."&artlang=".$lang, $_SERVER["PHP_SELF"]); ?></a></p>

<p id="footer">&copy; <?php print date("Y")." ".$PMF_CONF["metaPublisher"]; ?> | <a href="mailto:<?php print safeEmail($PMF_CONF["adminmail"]); ?>"><?php print safeEmail($PMF_CONF["adminmail"]); ?></a></p>

<?php
		}
	}
else {
	print $err_badID;
	}
?>
<p id="close"><a href="javascript:self.print()"><?php print $PMF_LANG["msgPrintArticle"]; ?></a></p>

</body>
</html>
