#!/usr/local/bin/php
<?php
/******************************************************************************
 * File:				cron4rss.php
 * Description:			PHP page for generating the RSS feeds with a cronjob
 * Author:				Thorsten Rinne <thorsten@phpmyfaq.de>
 * Date:				2003-08-04
 * Last change:			2004-09-05
 * Copyright:           (c) 2001-2004 Thorsten Rinne
 * 
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific language governing rights and limitations
 * under the License.
 *
 * Add to your cron.d:
 -------------------------------------------------------------------------------
 0 * * * * /usr/local/bin/php -f /path/to/your/faq//xml/cron4rss.php
 -------------------------------------------------------------------------------
 ******************************************************************************/

require_once ("../inc/data.php");
require_once ("../inc/config.php");
require_once ("../inc/constants.php");
require_once ("../inc/mysql.php");
define("SQLPREFIX", $DB["prefix"]);
$db = new DB();
$db->connect($DB["server"], $DB["user"], $DB["password"], $DB["db"]);
require_once ("../inc/category.php");
require_once ("../inc/functions.php");

$result = $db->query("SELECT datum, header, artikel, link, linktitel, target FROM ".SQLPREFIX."faqnews ORDER BY datum desc LIMIT 0,".$PMF_CONF["numNewsArticles"]);

$output = "<?xml version=\"1.0\" encoding=\"".$PMF_LANG["metaCharset"]."\" standalone=\"yes\" ?>\n<rss version=\"2.0\">\n<channel>\n";
$output .= "<title>".$PMF_CONF["title"]."</title>\n";
$output .= "<description>".$PMF_CONF["metaDescription"]."</description>\n";
$output .= "<link>http://".$_SERVER["HTTP_HOST"].str_replace("xml/cron4rss.php", "", $_SERVER["PHP_SELF"])."</link>";
if ($db->num_rows($result) > 0) {
    while ($row = $db->fetch_object($result)) {
        $output .= "\t<item>\n";
        $output .= "\t\t<title>".$row->header."</title>\n";
        $output .= "\t\t<description>".stripslashes($row->artikel)."</description>\n";
        $output .= "\t\t<link>http://".$_SERVER["HTTP_HOST"].str_replace("xml/cron4rss.php", "", $_SERVER["PHP_SELF"])."</link>\n";
        $output .= "\t</item>\n";
        }
    }
$output .= "</channel>\n</rss>";
$fp = @fopen("news.xml", "w");
fputs($fp, $output);
fclose($fp);
unset($result);

$result = $db->query("SELECT DISTINCT ".SQLPREFIX."faqdata.id, ".SQLPREFIX."faqdata.lang, ".SQLPREFIX."faqdata.thema, ".SQLPREFIX."faqdata.rubrik, ".SQLPREFIX."faqvisits.visits FROM ".SQLPREFIX."faqvisits, ".SQLPREFIX."faqdata WHERE ".SQLPREFIX."faqdata.id = ".SQLPREFIX."faqvisits.id AND ".SQLPREFIX."faqdata.lang = ".SQLPREFIX."faqvisits.lang AND ".SQLPREFIX."faqdata.active = 'yes' ORDER BY ".SQLPREFIX."faqvisits.visits DESC LIMIT 0,10");

$output = "<?xml version=\"1.0\" encoding=\"".$PMF_LANG["metaCharset"]."\" standalone=\"yes\" ?>\n<rss version=\"2.0\">\n<channel>\n";
$output .= "<title>".$PMF_CONF["title"]."</title>\n";
$output .= "<description>".$PMF_CONF["metaDescription"]."</description>\n";
$output .= "<link>http://".$_SERVER["HTTP_HOST"]."</link>";
if ($db->num_rows($result) > 0) {
    $i = 1;
        while ($row = $db->fetch_object($result)) {
        $output .= "\t<item>\n";
        $output .= "\t\t<title>[".$i.".] ".$row->visits." ".$msgViews.":</title>\n";
        $output .= "\t\t<description>".stripslashes(makeShorterText($row->thema, 8))."</description>\n";
        $output .= "\t\t<link>http://".$_SERVER["HTTP_HOST"].str_replace("xml/cron4rss.php", "index.php", $_SERVER["PHP_SELF"])."?action=artikel&amp;cat=".$row->rubrik."&amp;id=".$row->id."&amp;artlang=".$row->lang."</link>\n";
        $output .= "\t</item>\n";
        $i++;
        }
    }
$output .= "</channel>\n</rss>";
$fp = fopen("topten.xml", "w");
fputs($fp, $output);
fclose($fp);
unset($result);

$result = $db->query("SELECT DISTINCT ".SQLPREFIX."faqdata.id, ".SQLPREFIX."faqdata.lang, ".SQLPREFIX."faqdata.rubrik, ".SQLPREFIX."faqdata.thema, ".SQLPREFIX."faqdata.datum, ".SQLPREFIX."faqvisits.visits FROM ".SQLPREFIX."faqdata, ".SQLPREFIX."faqvisits WHERE ".SQLPREFIX."faqdata.id = ".SQLPREFIX."faqvisits.id AND ".SQLPREFIX."faqdata.lang = ".SQLPREFIX."faqvisits.lang AND ".SQLPREFIX."faqdata.active = 'yes' ORDER BY ".SQLPREFIX."faqdata.datum desc LIMIT 0,5");

$output = "<?xml version=\"1.0\" encoding=\"".$PMF_LANG["metaCharset"]."\" standalone=\"yes\" ?>\n<rss version=\"2.0\">\n<channel>\n";
$output .= "<title>".$PMF_CONF["title"]."</title>\n";
$output .= "<description>".$PMF_CONF["metaDescription"]."</description>\n";
$output .= "<link>http://".$_SERVER["HTTP_HOST"]."</link>";
if ($num = $db->num_rows($result) > 0) {
    while ($row = $db->fetch_object($result)) {
        $output .= "\t<item>\n";
        $output .= "\t\t<title>".stripslashes(makeShorterText($row->thema, 8))." ...</title>\n";
			$output .= "\t\t<description>".stripslashes($row->thema)." (".$row->visits." ".$PMF_LANG["msgViews"]." - makeDate($row->datum))</description>\n";
        $output .= "\t\t<link>http://".$_SERVER["HTTP_HOST"].str_replace("xml/cron4rss.php", "index.php", $_SERVER["PHP_SELF"])."?action=artikel&amp;cat=".$row->rubrik."&amp;id=".$row->id."&amp;artlang=".$row->lang."</link>\n";
        $output .= "\t</item>\n";
        }
    }
$output .= "</channel>\n</rss>";
$fp = fopen("latest.xml", "w");
fputs($fp, $output);
fclose($fp);
unset($result);
?>