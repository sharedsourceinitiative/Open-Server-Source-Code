# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Cycle through the browsers listed in browsers.conf.
Poll the server once a minute for jobs for each browser.
Call the screenshot generator commands and upload the results.
"""

__revision__ = "$Rev: 159 $"
__date__     = "$Date: 2005-05-21 21:55:56 +0200 (Sat, 21 May 2005) $"
__author__   = "$Author: johann $"

import sys, os, re, time

from lib import proc, vnc, shotserver

# Configuration
idle_load = 0.5 # First value in /proc/loadavg must be smaller than this

def usage(message = None):
    """
    Print a usage message and exit with return code 1.
    """
    if message:
        print "Error: " + message
    print "Usage: python factory.py" + \
          " <display> <resolution> <server> <user> <pass>"
    print "    <display>       virtual display for VNC server, e.g. :1"
    print "    <resolution>    width x height x depth (bits per pixel)" + \
          ", e.g. 800x600x16"
    print "    <server>        middle part of server URL" + \
          ", e.g. www.browsershots.org"
    print "    <user>          account nickname on ShotServer"
    print "    <pass>          account password on ShotServer"
    sys.exit(1)

def surf(browser, url, pngfiles):
    """
    Call the screenshot generator command.
    """
    command = browser["command"]
    command += " --display " + options["display"]
    command += " --url " + url
    for page, pngfile in pngfiles.iteritems():
        command += " " + pngfile
    print command
    vnc.system(command)

def trigger_sleep():
    """
    Sleep until the trigger second has come.
    """
    now = time.time()
    seconds = time.localtime(now).tm_sec
    if seconds < options["trigger"]:
        sleep = options["trigger"] - seconds
    else:
        sleep = 60 + options["trigger"] - seconds
    wakeup = time.localtime(now + sleep)
    print "Sleeping until %s..." % \
          time.strftime("%H:%M:%S", wakeup)
    time.sleep(sleep)

# Regular expressions
re_resolution = re.compile(r"(\d+)x(\d+)x(\d+)")
re_key_value = re.compile(r"(\w+):\s+(\S.*)")
re_display = re.compile(r":(\d+)")

def browsers_conf():
    """
    Parse browser configuration from file browsers.conf.
    """
    filename = "browsers.conf"
    infile = file(filename)
    lines = infile.readlines()
    infile.close()

    config = {}
    config["username"] = options["username"]
    config["password"] = options["password"]

    result = []
    for lineno, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            continue
        match = re_key_value.match(line)
        if match is None:
            raise RuntimeError, \
                  "Syntax error on line %d in %s." % \
                  (lineno + 1, filename)
        key, value = match.groups()
        config[key] = value
        if key == "command":
            if not config.has_key("resolution"):
                raise RuntimeError, \
                      "Browser has no resolution on line %d in %s." % \
                      (lineno + 1, filename)
            match = re_resolution.match(config["resolution"])
            if match:
                config["width"] = int(match.group(1))
                config["height"] = int(match.group(2))
                config["depth"] = int(match.group(3))
            elif config["resolution"] == "any":
                config["resolution"] = options["resolution"]
                config["width"] = options["width"]
                config["height"] = options["height"]
                config["depth"] = options["depth"]
            else:
                raise RuntimeError, \
                      "Invalid resolution on line %d in %s." % \
                      (lineno + 1, filename)
            result.append(config.copy())

    return result

def delete_old_png_files():
    """
    Delete all local PNG files that are older than 24 hours.
    """
    err = os.system('find -type f -name "*.png" -mtime +1 | xargs rm -f')
    if err:
        raise RuntimeError, "deleting old PNGs failed, exit code %d" % err

def dotfiles():
    """
    Reload all browser configuration from dotfiles folder.
    """
    print "Reloading dotfiles..."
    os.system("gconftool-2 --shutdown")
    for filename in os.listdir("dotfiles"):
        dotfile = "." + filename
        vnc.os_system("rm -rf " + dotfile)
        vnc.os_system("cp -r dotfiles/%s %s" % (filename, dotfile))

def print_factory_info():
    """Print screenshot factory identification."""
    print "%s@%s%s %s" % (loginname, hostname, vnc.display,
                          options["resolution"])

idle_str = "%.2f" % idle_load

def try_browser(browser):
    """
    Try to get a job and process it.
    """
    if browser["width"] != options["width"]:
        return False
    if browser["height"] != options["height"]:
        return False
    if browser["depth"] > options["depth"]:
        return False

    print_factory_info()
    slept = 0
    while True:
        load = proc.loadavg()
        if load <= idle_load:
            break
        load_str = "%.2f" % load
        if load_str == idle_str:
            break
        print "System load average %s exceeds %s." % (load_str, idle_str),
        trigger_sleep()
        slept += 1
    if slept:
        print
        print_factory_info()

    print "Looking for a job for %s..." % browser["browser"]
    hashkey, redir_url, upload_form, pages = \
             shotserver.poll(options["server"], browser)
    if hashkey is None:
        print "No matching job found.",
        trigger_sleep()
        print
        return False
    print "Found job, hashkey %s." % hashkey

    pngfiles = {}
    for page in pages:
        pngfiles[page] = "%s-%s.png" % (hashkey, page)

    dotfiles()
    surf(browser, redir_url, pngfiles)
    shotserver.upload(upload_form, browser, pngfiles)
    trigger_sleep()
    return True

def list_browsers():
    """
    Show the configured browsers that match our resolution.
    """
    for browser in browsers:
        if browser["width"] != options["width"]:
            continue
        if browser["height"] != options["height"]:
            continue
        if browser["depth"] > options["depth"]:
            continue
        print browser["browser"]

def cycle_browsers():
    """
    Loop through configured browsers.
    """
    print "Starting VNC server on display %s with resolution %dx%dx%d..." % \
          (options["display"],
           options["width"], options["height"], options["depth"])
    vnc. display = options["display"]
    vnc.start(options["width"], options["height"], options["depth"])
    time.sleep(2)
    try:
        try:
            while True:
                delete_old_png_files()
                for browser in browsers:
                    try_browser(browser)
                vnc.stop()
                time.sleep(4)
                vnc.start(options["width"], options["height"],
                          options["depth"])
        finally:
            print "Killing VNC server..."
            vnc.stop()
    except KeyboardInterrupt:
        print "Stopped gracefully with keyboard interrupt."

def command_line():
    """
    Read command line options
    """
    try:
        sys.argv.pop(0)
        display, resolution, server, username, password  = sys.argv
    except ValueError:
        usage("Wrong number of command line arguments.")

    match = re_resolution.match(resolution)
    try:
        width, height, depth = match.groups()
        width = int(width)
        height = int(height)
        depth = int(depth)
    except (re.IndexError, ValueError):
        usage("Bad <resolution> syntax in %s." % resolution)

    match = re_display.match(display)
    try:
        trigger = int(match.group(1))
    except re.IndexError:
        usage("Bad <display> syntax in %s." % display)
    trigger = (trigger * 23) % 60

    result = {}
    result["display"] = display
    result["resolution"] = resolution
    result["width"] = width
    result["height"] = height
    result["depth"] = depth
    result["server"] = server
    result["username"] = username
    result["password"] = password
    result["trigger"] = trigger
    return result

loginname = vnc.backticks("whoami").strip()
hostname = vnc.backticks("hostname").strip()
options = command_line()
browsers = browsers_conf()

print "Configured browsers:"
list_browsers()
print

cycle_browsers()
