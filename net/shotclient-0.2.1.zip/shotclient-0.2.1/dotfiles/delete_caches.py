"""
Delete browser caches for faster config cloning.
"""

__revision__ = '$Rev: 88 $'
__date__     = '$Date: 2005-03-06 11:06:30 +0100 (Sun, 06 Mar 2005) $'
__author__   = '$Author: johann $'

import os

def system(command):
    """
    Run a shell command with error checking.
    """
    print command
    err = os.system(command)
    if err:
        print "failed with exit code %d" % err
        return False
    return True

def rmrf(path):
    """
    Recursively delete files.
    """
    if not os.path.exists(path):
        return False
    return system('rm -rf ' + path)

def delete_mozilla_caches(path):
    """
    Find and delete mozilla caches.
    """
    print "Checking %s..." % path
    if not os.path.isdir(path):
        return
    for profile in os.listdir(path):
        print "Checking %s/%s..." % (path, profile)
        rmrf(path + '/' + profile + '/Cache')
        rmrf(path + '/' + profile + '/Cache.Trash')

def delete_cache(path):
    """
    Directly delete a browser cache.
    """
    print "Checking %s..." % path
    rmrf(path)

delete_mozilla_caches('mozilla/firefox')
delete_mozilla_caches('galeon/mozilla')
delete_cache('opera/cache4')
delete_cache('elinks/globhist')
delete_cache('elinks/gotohist')
