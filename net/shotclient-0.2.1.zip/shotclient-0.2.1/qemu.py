# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Run QEMU and make a browser screenshot.
"""

__revision__ = '$Rev: 158 $'
__date__     = '$Date: 2005-05-21 18:02:19 +0200 (Sat, 21 May 2005) $'
__author__   = '$Author: johann $'

import sys, time, os

from lib import vnc

arg0 = sys.argv.pop(0)
image = sys.argv.pop(0)
alt_f11 = False # Fullscreen workaround

while len(sys.argv):
    key = sys.argv.pop(0)
    if key == '--display':
        vnc.display = sys.argv.pop(0)
    elif key == '--url':
        url = sys.argv.pop(0)
    elif key == '--pngfile':
        pngfile = sys.argv.pop(0)
    elif key == '--alt-f11':
        alt_f11 = True
    else:
        raise RuntimeError, "unknown option " + key

print "Starting QEMU..."
command = 'qemu -hda %s -snapshot -user-net -k en-us' % image
if not alt_f11:
    command += ' -full-screen'
vnc.system(command + ' &')
time.sleep(30)

if alt_f11:
    print "Maximizing to fullscreen..."
    vnc.xte_alt('F11')
    time.sleep(1)

# Open URL input box
vnc.xte_control('o')
time.sleep(1)

# Do it again, now it works
vnc.xte_control('o')
time.sleep(1)

# Send URL
vnc.xte_slow_str(url)
vnc.xte('key Return')
time.sleep(40)

vnc.screenshot(pngfile)

print "Killing QEMU..."
os.system('killall qemu')
