# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
This will copy some configuration files from one home directory to
another so you don't have to configure browsers again and again for
each screenshot factory.

In the source home directory (e.g. /home/user1) do
# chmod -R a+r dotfiles
# find dotfiles -type d | xargs chmod a+rx

Then login as user2. From within /home/user2, you can do
# python clone-config.py ../user1
"""

__revision__ = '$Rev: 118 $'
__date__     = '$Date: 2005-04-02 20:36:12 +0200 (Sat, 02 Apr 2005) $'
__author__   = '$Author: johann $'

import sys, os

arg0, source = sys.argv
while source.endswith('/'):
    source = source[:-1]

def system(command):
    """Echo and run a shell command."""
    print command
    os.system(command)

def clone(filename):
    """Copy a config file or folder, delete old data first."""
    system('rm -rf %s' % filename)
    system('cp -r %s/%s .' % (source, filename))

# Login and usability
clone('.ssh')
clone('.bash_profile')
clone('.bashrc')
clone('.emacs')

# Browsers config
clone('browsers.conf')
clone('dotfiles')
