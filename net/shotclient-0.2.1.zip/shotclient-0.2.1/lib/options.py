def read_options(argv):
    arg0 = argv.pop(0)
    browser = argv.pop(0)
    pngfiles = []
    while len(argv):
        key = argv.pop(0)
        if key == '--display':
            display = argv.pop(0)
        elif key == '--url':
            url = argv.pop(0)
        elif key.endswith(".png"):
            pngfiles.append(key)
        else:
            raise RuntimeError, "Unknown option " + key
    return browser, display, url, pngfiles
