# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Capture screenshots of multiple pages.
"""

__revision__ = '$Rev: 141 $'
__date__     = '$Date: 2005-05-14 21:48:46 +0200 (Sat, 14 May 2005) $'
__author__   = '$Author: johann $'

import time, re
import vnc

def page_numbers(pngfiles, prefix):
    """
    Get all page numbers that have the specified prefix.
    Returns a dict that maps integers to pngfiles.
    """
    re_page_number = re.compile(prefix + "(\d+)")
    pages = {}
    for pngfile in pngfiles:
        match = re_page_number.search(pngfile)
        if match is None:
            continue
        pages[int(match.group(1))] = pngfile
    return pages

def page_shots(pngfiles, direction, key_start, key_step):
    """
    Take all requested shots in one direction, scrolling pages in the
    browser between shots.
    """
    page = 1
    pages = page_numbers(pngfiles, direction)
    vnc.xte('key ' + key_start)
    while True:
        if pages.has_key(page):
            pngfile = pages[page]
            time.sleep(1)
            vnc.screenshot(pngfile)
            del(pages[page])
            if not pages:
                break
        vnc.xte('key ' + key_step)
        page += 1
