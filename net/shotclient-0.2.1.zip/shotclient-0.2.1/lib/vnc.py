# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Some simple tools for running programs on a VNC server.
"""

__revision__ = "$Rev: 156 $"
__date__     = "$Date: 2005-05-20 08:09:32 +0200 (Fri, 20 May 2005) $"
__author__   = "$Author: johann $"

import os, time

display = ":0"

def backticks(command):
    """
    Run a shell command and return its output as a string.
    """
    child = os.popen(command)
    data = child.read()
    err = child.close()
    if err:
        raise RuntimeError, \
              "%s failed with exit code %d" % (command, err)
    return data

def os_system(command):
    """
    Run a shell command and check for errors.
    """
    err = os.system(command)
    if err:
        raise RuntimeError, \
              "%s failed with exit code %d" % (command, err)

def start(width, height, depth):
    """
    Start the VNC server.
    """
    error = True
    while error:
        try:
            os_system("vncserver -geometry %dx%d -depth %d %s" % \
                      (width, height, depth, display))
            error = False
        except RuntimeError, err:
            time.sleep(10)

def stop():
    """
    Stop the VNC server.
    """
    os.system("vncserver -kill " + display)
    # os.system("gconftool-2 --shutdown")
    time.sleep(1)
    os.system("killall -9 vncserver")
    # os.system("killall -9 gconfd-2")

def system(command):
    """
    Run a shell command on our display.
    """
    os_system("DISPLAY=%s %s" % (display, command))

def xte(command):
    """
    Send a key to the VNC server and take a short nap.
    """
    os_system('xte -x %s "%s"' % (display, command))

def xte_alt(key):
    """
    Send Alt+Key to the VNC server.
    """
    xte("keydown Alt_L")
    time.sleep(0.1)
    xte("key " + key)
    time.sleep(0.1)
    xte("keyup Alt_L")

def xte_control(key):
    """
    Send Control+Key to the VNC server.
    """
    xte("keydown Control_L")
    time.sleep(0.1)
    xte("key " + key)
    time.sleep(0.1)
    xte("keyup Control_L")

def xte_slow_str(text):
    """
    Send a string to the VNC server.
    """
    print "Sending string %s..." % text
    for char in text:
        command = "key " + char
        xte(command)
        time.sleep(0.1)

def screenshot(filename):
    """
    Take a fullscreenshot and save it in a PNG file.
    """
    print "Taking screenshot of display %s..." % display
    os_system("xwd -display %s -root | xwdtopnm | pnmtopng > %s" % \
              (display, filename))
