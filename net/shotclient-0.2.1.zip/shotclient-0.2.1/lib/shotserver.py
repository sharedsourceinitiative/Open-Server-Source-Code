# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
ShotServer interface.
"""

__revision__ = "$Rev: 148 $"
__date__     = "$Date: 2005-05-16 10:28:18 +0200 (Mon, 16 May 2005) $"
__author__   = "$Author: johann $"

import urllib2, ClientForm, socket

def try_urlopen(request):
    """
    Try to open a URL.
    Return None on error.
    """
    print request.get_method(), request.get_full_url()
    try:
        response = urllib2.urlopen(request)
        return response
    except (urllib2.URLError, socket.error, socket.sslerror):
        return None

def try_urlopen_form(request):
    """
    Try to open a URL and return the first form.
    Return None on error.
    """
    response = try_urlopen(request)
    if response is None:
        return None

    # print response.read()
    forms = ClientForm.ParseResponse(response)
    response.close()
    if len(forms) == 0:
        return None

    return forms[0]

def poll(server, options):
    """
    Check for a matching job in the queue.
    """
    url = "https://%s/poll/" % server
    request = urllib2.Request(url)
    poll_form = try_urlopen_form(request)
    if poll_form is None:
        return None, None, None, None

    for control in poll_form.controls:
        key = control.name
        if key == "submit" or not key:
            pass
        elif options.has_key(key):
            control.value = str(options[key])
            # print "%s: %s" % (control.name, control.value)
        else:
            print "Warning: no value for '%s'" % key

    request = poll_form.click()
    upload_form = try_urlopen_form(request)
    if upload_form is None:
        return None, None, None, None

    hashkey = upload_form.find_control("hashkey").value
    redir_url = "http://%s/redir/%s/" % (server, hashkey)

    pages = []
    for control in upload_form.controls:
        key = control.name
        if key is None:
            continue
        if key.startswith("pgdn") or key.startswith("pgup"):
            pages.append(key)
    return hashkey, redir_url, upload_form, pages

def upload(upload_form, options, pngfiles):
    """
    Upload a job to the server.
    """
    for control in upload_form.controls:
        key = control.name
        if key is None:
            continue
        if control.readonly:
            print "skipping", key, control.value
        elif key in ("username", "hashkey"):
            control.value = options[key]
            print "sending", key, options[key]
        elif key == "password":
            control.value = options[key]
            print "sending", key, "********"
        elif key.startswith("pgdn") or key.startswith("pgup"):
            control.add_file(open(pngfiles[key]),
                             "image/png", pngfiles[key])
            print "sending", key, pngfiles[key]
        else:
            print "unknown key", key
    request = upload_form.click()
    response = try_urlopen(request)
    if response is not None:
        print response.read()
        response.close()
