# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Read system load average from /proc/loadavg.
"""

__revision__ = "$Rev: 159 $"
__date__     = "$Date: 2005-05-21 21:55:56 +0200 (Sat, 21 May 2005) $"
__author__   = "$Author: johann $"

import re

number = re.compile(r"(\d+\.\d+)\s")

def loadavg():
    """
    Read system load average from /proc/loadavg.
    Return a float value.
    """
    infile = file("/proc/loadavg")
    line = infile.readline()
    infile.close()
    match = number.match(line)
    return float(match.group(1))
