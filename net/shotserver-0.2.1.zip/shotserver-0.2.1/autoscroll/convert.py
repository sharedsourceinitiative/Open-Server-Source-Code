import sys, os

sys.argv.pop(0)
for png in sys.argv:
    ppm = "ppm/" + os.path.basename(png).replace(".png", ".ppm")
    print png, ppm
    os.system("pngtopnm %s > %s" % (png, ppm))

