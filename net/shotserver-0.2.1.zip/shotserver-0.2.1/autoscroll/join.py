import sys, re, os

def backticks(command):
    """
    Run a shell command and return its output as a string.
    """
    child = os.popen(command)
    data = child.read()
    err = child.close()
    if err:
        raise RuntimeError, \
              '%s failed with exit code %d' % (command, err)
    return data

arg0 = sys.argv.pop(0)
re_dn = re.compile(r".*pgdn(\d+)\.p.m$")
re_up = re.compile(r".*pgup(\d+)\.p.m$")

dn = []
up = []

for filename in sys.argv:
    match = re_dn.match(filename)
    if match:
        dn.append(filename)
    match = re_up.match(filename)
    if match:
        up.append(filename)

dn.sort()
up.sort()
up.reverse()

chrome = backticks("./findchrome %s %s" % (" ".join(dn), " ".join(up)))
chrome = chrome.strip().split(" ")
width = int(chrome[0])
height = int(chrome[1])
top = int(chrome[2])
bottom = int(chrome[3])
print "found image size: width=%dpx, height=%dpx" % (width, height)
print "found browser chrome: top=%dpx, bottom=%dpx" % (top, bottom)

def join(files, keep):
    allfilename = files[0] + ".all"
    if len(files) > 1:
        command = "./overlap %d %d %s" % (top, bottom, " ".join(files))
        print command
        overlaps = backticks(command)
        overlaps = overlaps.strip().split(" ")
    for index, filename in enumerate(files):
        print index, filename,
        cut_top = top
        cut_bottom = bottom
        if index < len(files) - 1:
            overlap = int(overlaps[index])
            print "o%d" % overlap,
            cut_bottom += overlap - (overlap / 2)
        if index > 0:
            overlap = int(overlaps[index - 1])
            cut_top += overlap / 2
        if keep == "top" and index == 0:
            print "t",
            cut_top = 0
        elif keep == "bottom" and index == len(files) - 1:
            print "b",
            cut_bottom = 0
        print "t%d" %cut_top,
        print "b%d" %cut_bottom,
        cutfilename = filename + ".cut"
        if len(files) == 1: # if there is only on page
            cutfilename = allfilename # write directly to .all file
        command = "pnmcut -top %d -bottom %d %s > %s" % \
                  (cut_top, -cut_bottom - 1, filename, cutfilename)
        print command
        os.system(command)
    if len(files) > 1:
        command = "pnmcat -tb"
        for filename in files:
            command += " " + filename + ".cut"
        command += " > " + allfilename
        print command
        os.system(command)
    return allfilename

allfile = dn[0][0:32] + ".ppm"
if top == height or bottom == height:
    command = "cp -f %s %s" % (dn[0], allfile)
    print command
    os.system(command)
    sys.exit()

dnfile = join(dn, "top")
upfile = join(up, "bottom")

command = "./overlap 0 0 %s %s" % (dnfile, upfile)
print command
overlap = int(backticks(command).strip())
print "found top-bottom overlap: %dpx" % overlap

if overlap:
    half1 = overlap / 2
    command = "pnmcut -bottom %d %s > %s.cut" % (-half1 - 1, dnfile, dnfile)
    print command
    os.system(command)

    half2 = overlap - half1
    command = "pnmcut -top %d %s > %s.cut" % (half2, upfile, upfile)
    print command
    os.system(command)

    command = "pnmcat -tb %s.cut %s.cut > %s" % (dnfile, upfile, allfile)
    print command
    os.system(command)
else:
    command = "pnmcat -tb %s %s > %s" % (dnfile, upfile, allfile)
    print command
    os.system(command)
