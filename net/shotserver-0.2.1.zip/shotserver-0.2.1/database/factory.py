# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Database interface for the factory table.
"""

__revision__ = '$Rev: 377 $'
__date__     = '$Date: 2005-04-19 19:16:46 +0200 (Tue, 19 Apr 2005) $'
__author__   = '$Author: johann $'

import MySQLdb
import shotserver02.database as db

keys = "arch os browser engine resolution lang flash java javascript"
keys = keys.split(" ")

def polled(info):
    """
    Try to insert a factory into the factory table, or update polled
    timestamp if the record already exists.

    Parameter info must be a mapping object (dict) that contains the
    keys in the module-level variable 'keys' which defaults to: arch,
    os, browser, engine, resolution, lang, flash, java, javascript.
    Additionally, the username key must be set.
    """
    try:
        set = ''
        for key in keys:
            set += "%s = '%s', " % (key, info[key])
        set += "username = '%s', " % info["username"]
        set += "polled = NOW(), firstpoll = NOW()"
        sql = "INSERT INTO factory SET " + set
        db.cursor.execute(sql)
        return db.conn.insert_id()
    except MySQLdb.IntegrityError:
        where = ''
        for key in keys:
            where += "%s = '%s' AND " % (key, info[key])
        where += "username = '%s'" % info["username"]
        sql = "SELECT id FROM factory WHERE " + where
        # raise sql
        db.cursor.execute(sql)
        factory_id = db.cursor.fetchone()["id"]
        sql = "UPDATE factory SET polled = NOW()" + \
              " WHERE id = %u" % factory_id
        db.cursor.execute(sql)
        return factory_id

def uploaded(factory_id):
    """
    Save information when a job has been finished.
    """
    db.update("factory", "uploaded = NOW()", "id = %d" % factory_id)

def active():
    sql = "SELECT id, browser, engine, os, arch"
    sql += ", MIN(UNIX_TIMESTAMP()-UNIX_TIMESTAMP(polled)) as polled"
    sql += ", MIN(UNIX_TIMESTAMP()-UNIX_TIMESTAMP(uploaded)) as uploaded"
    sql += " FROM factory"
    sql += " GROUP BY browser, os"
    sql += " ORDER BY polled"
    db.cursor.execute(sql)
    return db.cursor.fetchall()
