# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Library for database access.
"""

__revision__ = '$Rev: 324 $'
__date__     = '$Date: 2005-04-09 11:19:38 +0200 (Sat, 09 Apr 2005) $'
__author__   = '$Author: johann $'

import MySQLdb

conn = None
cursor = None

def connect():
    """
    Connect to the webshots database.
    """
    global conn, cursor
    db_name = "browsershots02"
    conn = MySQLdb.connect(host = "localhost", db = db_name,
                           user = db_name, passwd = "pa%sss" % db_name)
    cursor = conn.cursor(MySQLdb.cursors.DictCursor)

def disconnect():
    """
    Disconnect from the webshots database.
    """
    cursor.close()
    conn.commit()
    conn.close()


def update(table, set, where):
    """
    Set some columns for certain rows.
    """
    cursor.execute("UPDATE `%s`" % table +
                   " SET %s" % set +
                   " WHERE %s" % where)
    return cursor.rowcount

def select_star(table, where):
    """
    Select all columns from all matching rows.
    """
    cursor.execute("SELECT * FROM `%s`" % table +
                   " WHERE %s" % where)
    return cursor.fetchall()

def select_some(table, columns, where):
    """
    Select some columns from all matching rows.
    """
    cursor.execute("SELECT %s" % columns +
                   " FROM `%s`" % table +
                   " WHERE %s" % where)
    return cursor.fetchall()

def select1_star(table, where):
    """
    Select all columns from one row.
    """
    cursor.execute("SELECT * FROM `%s`" % table +
                   " WHERE %s" % where +
                   " LIMIT 1")
    return cursor.fetchone()

def select1_some(table, columns, where):
    """
    Select some columns from one row.
    """
    cursor.execute("SELECT %s" % columns +
                   " FROM `%s`" % table +
                   " WHERE %s" % where +
                   " LIMIT 1")
    return cursor.fetchone()

def select1_column(table, column, where):
    """
    Select one column from one row.
    """
    cursor.execute("SELECT `%s`" % column +
                   " FROM `%s`" % table +
                   " WHERE %s" % where +
                   " LIMIT 1")
    row = cursor.fetchone()
    return row[column]
