# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Database interface for the lock table.
"""

__revision__ = '$Rev: 375 $'
__date__     = '$Date: 2005-04-19 18:10:23 +0200 (Tue, 19 Apr 2005) $'
__author__   = '$Author: johann $'

import MySQLdb
import shotserver02.database as db

timeout = 2 * 60 # 2 minutes

class LockError(Exception):
    """The job has already been locked by somebody else."""
    def __init__(self, locktime):
        Exception.__init__(self)
        self.locktime = locktime

def insert(jobid, worker):
    """
    Try to insert a lock into the lock table.
    Remove other stale locks on-the-fly.
    """
    while True:
        try:
            db.cursor.execute("INSERT INTO `lock`" +
                              " SET job = %d" % jobid +
                              ", worker = '%s'" % worker)
            return db.conn.insert_id()
        except MySQLdb.IntegrityError:
            db.cursor.execute("SELECT job,"
                              " UNIX_TIMESTAMP()-UNIX_TIMESTAMP(locked)" +
                              " AS age FROM `lock` WHERE job=%d" % jobid)
            row = db.cursor.fetchone()
            age = row['age']
            if age < timeout:
                raise LockError(age)
            db.cursor.execute("DELETE FROM `lock` WHERE job = %d" %
                              row['job'])
