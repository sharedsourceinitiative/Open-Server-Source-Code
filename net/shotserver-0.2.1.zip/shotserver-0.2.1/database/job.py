# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Database interface for the job table.
"""

__revision__ = "$Rev: 448 $"
__date__     = "$Date: 2005-05-19 21:41:38 +0200 (Thu, 19 May 2005) $"
__author__   = "$Author: johann $"

import md5, time, random

import shotserver02.database as db
from shotserver02.database import lock

default_history_timeout = 30 * 24 * 60 * 60 # 30 days

def md5hash(data):
    """
    Make a unique 32-digit hex key.
    """
    md5obj = md5.new()
    for value in data:
        md5obj.update(str(value))
    md5obj.update(str(time.time()))
    md5obj.update("%08d" % random.randint(0, 99999999))
    return md5obj.hexdigest()

def insert(options):
    """
    Insert a job into the queue.
    """
    pairs = []
    pairs.append("username = '%s'" % options["username"])
    pairs.append("url = '%s'" % options["url"])
    if options.has_key("browser"):
        pairs.append("browser = '%s%%'" % options["browser"])
    if options.has_key("resolution"):
        pairs.append("resolution = '%s%%'" % options["resolution"])
    if options.has_key("pgdn"):
        pairs.append("pgdn_count = %u" % options["pgdn"])
    if options.has_key("pgup"):
        pairs.append("pgup_count = %u" % options["pgup"])
    pairs.append("hashkey = '%s'" % md5hash((options)))
    pairs.append("submitted = NOW()")
    sql = "INSERT INTO job SET " + ", ".join(pairs)
    # raise sql
    db.cursor.execute(sql)
    return db.cursor.rowcount

def locked(job_id, factory_id):
    """
    Save information when a job has been locked.
    """
    set = []
    hashkey = md5hash((job_id, factory_id))
    set.append("hashkey = '%s'" % hashkey)
    set.append("factory = '%s'" % factory_id)
    set.append("locked = NOW()")
    db.update("job", ", ".join(set), "id=%d" % job_id)
    return hashkey

def redirected(hashkey, useragent):
    """
    Save information when the browser has been redirected.
    """
    set = []
    set.append("useragent = '%s'" % useragent)
    set.append("redirected = NOW()")
    db.update("job", ", ".join(set), "hashkey = '%s'" % hashkey)

def uploaded(hashkey):
    """
    Save information when a job has been finished.
    """
    db.update("job", "uploaded = NOW()", "hashkey = '%s'" % hashkey)

def get_url(job_id):
    """
    Get a job's URL.
    """
    return db.select1_column("job", "url", "id=%d" % job_id)

def find(options):
    """
    Find a job matching the screenshot factory options.
    """
    where = []
    where.append("UNIX_TIMESTAMP()-UNIX_TIMESTAMP(locked) > %d" %
                 lock.timeout)
    where.append("uploaded = 0")
    for key, value in options.iteritems():
        where.append("(`%s` IS NULL OR '%s' LIKE `%s`)" % (key, value, key))

    where = " AND ".join(where)
    if where:
        where = " WHERE " + where
    sql = "SELECT * FROM job" + where + " ORDER BY submitted ASC LIMIT 1"
    # raise sql
    db.cursor.execute(sql)
    row = db.cursor.fetchone()
    # raise str(row)
    return row

def open_jobs_by_url(url):
    """
    List open jobs for one URL.
    """
    return db.select_some("job", "browser, resolution",
                          "uploaded = 0 AND url = '%s'" % url)

def recently_uploaded(seconds = default_history_timeout):
    """
    List recently uploaded jobs, grouped by URL.
    """
    db.cursor.execute("SELECT id, hashkey, url, factory" +
                      " FROM job" +
                      " WHERE UNIX_TIMESTAMP()-UNIX_TIMESTAMP(uploaded)" +
                      " < %d" % seconds +
                      " ORDER BY uploaded DESC")
    rows = list(db.cursor.fetchall())
    index = 0
    count = {}
    while index < len(rows):
        job = rows[index]
        url = job["url"]
        if not count.has_key(url):
            count[url] = 1
            index += 1
        else:
            count[url] += 1
            rows.pop(index)
    for job in rows:
        job["count"] = count[job["url"]]
    return rows

def finished_by_url(url, seconds = default_history_timeout):
    """
    List all finished jobs for one URL.
    """
    db.cursor.execute("SELECT id, hashkey, resolution, browser, factory" +
                      " FROM job" +
                      " WHERE url = '%s'" % url +
                      " AND UNIX_TIMESTAMP()-UNIX_TIMESTAMP(uploaded)" +
                      " < %d" % seconds +
                      " ORDER BY uploaded DESC")
    return db.cursor.fetchall()
