# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Process all incoming requests for the web frontent.
"""

__revision__ = '$Rev: 361 $'
__date__     = '$Date: 2005-04-19 12:02:05 +0200 (Tue, 19 Apr 2005) $'
__author__   = '$Author: johann $'

from mod_python import apache
from liteweb import http, request

import gettext
localedir = __path__[0] + "/gettext/locale"

def deep_import(name):
    """
    Import a module from some.levels.deep and return the module
    itself, not its uppermost parent.
    """
    mod = __import__(name)
    components = name.split('.')
    for comp in components[1:]:
        mod = getattr(mod, comp)
    return mod

def body(request_info):
    """
    Load action module and return XHTML output.
    """
    trans = gettext.translation("shotserver", localedir,
                                languages = [request_info.lang.selected],
                                fallback = True)
    trans.add_fallback(request_info.trans)
    trans.install(unicode = True)

    mod_name = request_info.action
    mod_absolute = 'shotserver02.actions.' + mod_name
    mod = deep_import(mod_absolute)
    result = mod.body(request_info)

    request_info.trans.install(unicode = True)
    return result

def handler(req):
    """
    Process all incoming HTTP requests.
    """
    request_info = request.RequestInfo(req, '/shotserver/')
    request_info.trans = gettext.NullTranslations()

    try:
        result = body(request_info)
    except http.ExternalRedirect, redirect:
        req.headers_out['Location'] = redirect.location
        req.status = apache.HTTP_MOVED_TEMPORARILY
        return apache.HTTP_MOVED_TEMPORARILY

    req.content_type = "text/html"
    req.write("""\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Browsershots</title></head>
<body>
%s</body>
</html>
""" % result)
    return apache.OK
