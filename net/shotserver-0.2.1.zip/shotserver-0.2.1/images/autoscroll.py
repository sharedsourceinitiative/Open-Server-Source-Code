# Distributed Automatic Browser Screenshots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Find browser chrome and screenshot overlap, then join pages.
"""

__revision__ = '$Rev: 437 $'
__date__     = '$Date: 2005-05-16 12:39:05 +0200 (Mon, 16 May 2005) $'
__author__   = '$Author: johann $'

import os

binary_path = "/usr/local/lib/python2.3/site-packages/shotserver02/autoscroll"

def backticks(command):
    """
    Run a shell command and return its output as a string.
    """
    child = os.popen(command)
    data = child.read()
    err = child.close()
    if err:
        raise RuntimeError, \
              '%s failed with exit code %d' % (command, err)
    return data

def system(command):
    """
    Run a shell command and check return value for errors.
    """
    err = os.system(command)
    if err:
        raise RuntimeError, \
              '%s failed with exit code %d' % (command, err)

def findchrome(dnfiles, upfiles):
    """
    Analyse screenshot files and find top and bottom browser chrome.
    Also report width and height of input images.
    """
    chrome = backticks("%s/findchrome %s %s" %
                       (binary_path, " ".join(dnfiles), " ".join(upfiles)))
    chrome = chrome.strip().split(" ")
    width = int(chrome[0])
    height = int(chrome[1])
    top = int(chrome[2])
    bottom = int(chrome[3])
    result = {}
    result["width"] = width
    result["height"] = height
    result["top"] = top
    result["bottom"] = bottom
    return result

def join(files, allfilename, chrome, keep):
    """
    Join browser screenshots into one larger file.
    Returns the heights of the parts in pixel.
    """
    # width = chrome["width"]
    height = chrome["height"]
    top = chrome["top"]
    bottom = chrome["bottom"]
    parts = []

    if len(files) > 1:
        overlaps = backticks("%s/overlap %d %d %s" %
                             (binary_path, top, bottom, " ".join(files)))
        overlaps = overlaps.strip().split(" ")

    for index, filename in enumerate(files):
        # print index, filename,
        cut_top = top
        cut_bottom = bottom
        if index < len(files) - 1:
            overlap = int(overlaps[index])
            # print "o%d" % overlap,
            cut_bottom += overlap - (overlap / 2)
        if index > 0:
            overlap = int(overlaps[index - 1])
            cut_top += overlap / 2
        if keep == "top" and index == 0:
            # print "t",
            cut_top = 0
        elif keep == "bottom" and index == len(files) - 1:
            # print "b",
            cut_bottom = 0
        # print "t%d" % cut_top,
        # print "b%d" % cut_bottom,
        part = height - cut_top - cut_bottom
        parts.append(part)

        if part > 0:
            cutfilename = filename + ".cut"
            system("pnmcut -top %d -bottom %d %s > %s" % \
                   (cut_top, -cut_bottom - 1, filename, cutfilename))

    if len(files) == 1: # if there is only on page
        cutfilename = files[0] + ".cut"
        system("cp %s %s" % (cutfilename, allfilename))
    else: # concatenate multiple pages
        command = "pnmcat -tb"
        for index, filename in enumerate(files):
            if parts[index] > 0:
                command += " " + filename + ".cut"
        command += " > " + allfilename
        system(command)

    return parts

def join2(dnfile, upfile, allfile):
    """
    Join upper and lower screenshot combinations.
    Returns how many pixels were removed from the upper and lower part.
    """
    command = "%s/overlap 0 0 %s %s" % (binary_path, dnfile, upfile)
    overlap = int(backticks(command).strip())
    # print "found top-bottom overlap: %dpx" % overlap

    if overlap:
        half1 = overlap / 2
        system("pnmcut -bottom %d %s > %s.cut" % \
                  (-half1 - 1, dnfile, dnfile))

        half2 = overlap - half1
        system("pnmcut -top %d %s > %s.cut" % \
                  (half2, upfile, upfile))

        system("pnmcat -tb %s.cut %s.cut > %s" % \
                  (dnfile, upfile, allfile))
        return half1, half2
    else:
        system("pnmcat -tb %s %s > %s" % (dnfile, upfile, allfile))
        return 0, 0
