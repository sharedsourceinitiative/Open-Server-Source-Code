# Distributed Automatic Browser Screenshots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Process PNG image files.
"""

__revision__ = "$Rev: 467 $"
__date__     = "$Date: 2005-05-21 23:25:36 +0200 (Sat, 21 May 2005) $"
__author__   = "$Author: johann $"

import os, shutil, re

# Configuration
shotpath = "/var/www/browsershots.org/png"

def makeparent(filename):
    """
    Make parent directories if necessary.
    """
    dirname = os.path.dirname(filename)
    if not os.path.isdir(dirname):
        os.makedirs(dirname)

def pngfilename(width, hashkey, page):
    """Make an absolute PNG filename from width and hashkey."""
    return "%s/%s/%s-%s.png" % (shotpath, width, hashkey, page)

def copyfileobj(inputfile, hashkey, page):
    """
    Copy an uploaded file to the PNG storage folder.
    Return the name of the new file.
    """
    dest = pngfilename("full", hashkey, page)
    makeparent(dest)
    outputfile = open(dest, "wb")
    shutil.copyfileobj(inputfile, outputfile)
    return dest

def system(command):
    """
    Run a shell command and check return value for errors.
    Raise RuntimeError if exit code is non-zero.
    """
    err = os.system(command)
    if err:
        raise RuntimeError, \
              "shell command '%s'" % command + \
              " failed with exit code %d" % err

def pngtopnm(pngfile, hashkey, page, tmp = "/tmp"):
    """
    Unpack an uploaded PNG file to a portable pixmap (PNM).
    Return the full path to the new PNM filename.
    """
    pnmfile = "%s/%s-%s.pnm" % (tmp, hashkey, page)
    system("pngtopnm %s | pnmdepth 255 > %s" % (pngfile, pnmfile))
    return pnmfile

whitespace = " \t\r\n"
newline = "\r\n"
re_info = re.compile(r"(P\d)\s+(\d+)\s+(\d+)\s+(\d+)\s+")
def pnmheader(pnmfile):
    """
    Read information from the beginning of a PNM file.
    Input parameter pnmfile can be filename or file-like object.
    Return a dict with the following values:
    - "type" of PNM file (P4 / P5 / P6) as a string,
    - "width" and "height" in pixels as integers,
    - "resolution" WIDTHxHEIGHT as a string,
    - "maxval" as integer.
    """
    if type(pnmfile) is str:
        pnmfile = file(pnmfile, "r")
    head = ""
    while True:
        while True:
            char = pnmfile.read(1)
            if char in whitespace:
                break
            elif char == "#":
                while True:
                    char = pnmfile.read(1)
                    if char in newline:
                        break
            else:
                head += char
        head += " "
        if len(head) > 30:
            raise RuntimeError, "could not read PNM header"
        match = re_info.match(head)
        if match:
            width = int(match.group(2))
            height = int(match.group(3))
            maxval = int(match.group(4))
            return {"type":   match.group(1),
                    "width":  width,
                    "height": height,
                    "resolution": "%dx%d" % (width, height),
                    "maxval": maxval}

def pnmscaletopng(pnmfile, width, hashkey, page):
    """
    Scale a PNM file to a new width and convert to PNG.
    Return the full path to the new PNG filename.
    """
    pngfile = pngfilename(width, hashkey, page)
    makeparent(pngfile)
    command = "pnmscale -width %d %s" % (width, pnmfile)
    command += " | pnmtopng > %s" % pngfile
    system(command)
    return pngfile
