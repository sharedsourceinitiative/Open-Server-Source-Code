#! /bin/sh
# This will delete all PNG files that are older than 48 hours.
find /var/www/browsershots.org/png -name "*.png" -mtime +2 | xargs rm -vf
