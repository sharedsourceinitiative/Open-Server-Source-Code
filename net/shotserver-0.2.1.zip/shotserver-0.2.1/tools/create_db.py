# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Create the database `browsershots02` with all tables.
Attention: any previously existing database will be dropped.
The root password for mysql is read from /root/.my.cnf, so you may
have to run this script as root (we recommend sudo).
"""

__revision__ = '$Rev: 248 $'
__date__     = '$Date: 2005-03-08 15:18:22 +0100 (Tue, 08 Mar 2005) $'
__author__   = '$Author: johann $'

import re
import MySQLdb

re_key_value = re.compile(r"(\w+)\s*\=\s*(\S+)")

user = password = None
# Parse db admin and password from /root/.my.cnf
infile = file('/root/.my.cnf')
for line in infile.readlines():
    m = re_key_value.match(line)
    if m is None:
        continue
    key, value = m.groups()
    if key == 'user':
        user = value
    if key == 'password':
        password = value
infile.close()

if user is None:
    raise RuntimeError, "no user found in /root/.my.cnf"
if password is None:
    raise RuntimeError, "no password found in /root/.my.cnf"

# Create database
db_name = "browsershots02"
conn = MySQLdb.connect(host = "localhost",
                       user = user, passwd = password)
cursor = conn.cursor()
cursor.execute("DROP DATABASE IF EXISTS " + db_name)
cursor.execute("CREATE DATABASE " + db_name)

# Set permissions
cursor.execute("GRANT USAGE ON *.*" +
               " TO '%s'@'localhost'" % db_name +
               " IDENTIFIED BY 'pa%sss'" % db_name)
cursor.execute("GRANT SELECT, INSERT, UPDATE, DELETE" +
               " ON `%s`.*" % db_name +
               " TO '%s'@'localhost'" % db_name)

cursor.close()
conn.close()

# Create tables
conn = MySQLdb.connect(host = "localhost", db = db_name,
                       user = user, passwd = password)
cursor = conn.cursor()

# Users register online
cursor.execute("DROP TABLE IF EXISTS user")
cursor.execute("""CREATE TABLE user (
username   VARCHAR(20) PRIMARY KEY,
password   VARCHAR(41) NOT NULL,
email      VARCHAR(80) NOT NULL,

updated    TIMESTAMP,
verified   TIMESTAMP,
registered TIMESTAMP)
""")

# Customers submit jobs, workers process them
cursor.execute("DROP TABLE IF EXISTS job")
cursor.execute("""CREATE TABLE job (
id         INT AUTO_INCREMENT PRIMARY KEY,
url        VARCHAR(255) NOT NULL,

username   VARCHAR(20) NOT NULL,
arch       VARCHAR(20),
os         VARCHAR(40),
browser    VARCHAR(40),
engine     VARCHAR(40),
resolution VARCHAR(20),
lang       VARCHAR(5),
flash      VARCHAR(40),
java       VARCHAR(40),
javascript VARCHAR(40),

pgdn_count INT NOT NULL,
pgdn_skip  INT NOT NULL,
pgup_count INT NOT NULL,
pgup_skip  INT NOT NULL,

hashkey    VARCHAR(32)  NOT NULL UNIQUE,
useragent  VARCHAR(255),
factory    INT,

updated    TIMESTAMP,
uploaded   TIMESTAMP,
redirected TIMESTAMP,
locked     TIMESTAMP,
submitted  TIMESTAMP,

INDEX (url))
""")

# Workers must lock jobs before processing
cursor.execute("DROP TABLE IF EXISTS `lock`")
cursor.execute("""CREATE TABLE `lock` (
job      INT PRIMARY KEY,
username INT NOT NULL,
locked   TIMESTAMP)
""")

# Workers poll the job queue
cursor.execute("DROP TABLE IF EXISTS factory")
cursor.execute("""CREATE TABLE factory (
id         INT AUTO_INCREMENT PRIMARY KEY,

username   VARCHAR(20) NOT NULL,
arch       VARCHAR(20) NOT NULL,
os         VARCHAR(40) NOT NULL,
browser    VARCHAR(40) NOT NULL,
engine     VARCHAR(40) NOT NULL,
resolution VARCHAR(20) NOT NULL,
lang       VARCHAR(5)  NOT NULL,
flash      VARCHAR(40) NOT NULL,
java       VARCHAR(40) NOT NULL,
javascript VARCHAR(40) NOT NULL,

updated    TIMESTAMP,
polled     TIMESTAMP,
uploaded   TIMESTAMP,
firstpoll  TIMESTAMP,

UNIQUE INDEX (username, arch, os, browser, engine,
resolution, lang, flash, java, javascript))
""")

cursor.close()
conn.close()
