#! /bin/sh
# This will delete all temporary images that are older than 30 minutes.
find /tmp/ -name "*.pnm" -mmin +30 | xargs rm -vf
find /tmp/ -name "*.pnm.all" -mmin +30 | xargs rm -vf
find /tmp/ -name "*.pnm.all.cut" -mmin +30 | xargs rm -vf
find /tmp/ -name "*.pnm.cut" -mmin +30 | xargs rm -vf
find /tmp/ -name "*.pnm.cutt" -mmin +30 | xargs rm -vf
