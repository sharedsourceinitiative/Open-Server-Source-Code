"""
Watch incoming visitors in realtime. Use me like this:
tail -fn1000 /var/log/apache2/browsershots.org/access.log | python referrers.py
"""

import re, sys, time

#123.123.123.123 - - [17/May/2005:10:36:49 +0200]
# "GET /style/style.css HTTP/1.1" 200 71
# "http://www.browsershots.org/"
# "Mozilla/4.0 (compatible; MSIE 6.0; X11; Linux i686; en) Opera 8.0"
re_ref = re.compile(r'([\d\.]+)\s-\s-\s(\[.+?\])' +
                    r'\s"GET\s+(\S+)\s(.+?)"\s(\d+)\s(\d+)' +
                    r'\s"(\S+)"')

while True:
    line = sys.stdin.readline()
    if not line.strip():
        time.sleep(1)
    match = re_ref.match(line)
    if match:
        date = match.group(2)
        referrer = match.group(7)
        if referrer and not referrer == "-":
            if not referrer.startswith("http://www.browsershots.org"):
                print date, referrer
