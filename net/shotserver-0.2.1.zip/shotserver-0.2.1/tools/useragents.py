# Distributed Automatic Browser Screenshots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Guess browser features from User-Agent header.
"""

__revision__ = "$Rev: 467 $"
__date__     = "$Date: 2005-05-21 23:25:36 +0200 (Sat, 21 May 2005) $"
__author__   = "$Author: johann $"

import re

def guess_one(regex, keys, info):
    """
    Try to guess one feature (and perhaps the version number).
    If successful, store results in info dict.
    """
    match = regex.search(text)
    if match is None:
        return False
    for key, value in zip(keys.split(" "), match.groups()):
        if key.endswith("_ver"):
            add_key = key[:-4]
            info[add_key] += " " + value
        else:
            info[key] = value.strip()
    return True

# Opera/7.54 (X11; Linux i686; U)  [en]
# Mozilla/5.0 (Macintosh; U; PPC Mac OS X; de-de)
#     AppleWebKit/125.5.6 (KHTML, like Gecko) Safari/125.12

# model = re.compile(r"(Mozilla)/([\d\.]+)")
browser = re.compile(r"(Konqueror|Safari" +
                     r"|Opera" +
                     r"|Firefox|Galeon|Epiphany" +
                     r"|Netscape|MSIE" +
                     r"|Lynx" +
                     r")[/\s]*([\d\.]+|)")
engine = re.compile(r"(AppleWebKit|KHTML|Gecko|Opera|MSIE" +
                    r")[/\s]*([\d\.]+|)")
arch = re.compile(r"(i\d86|PPC)")
os = re.compile(r"(Linux|Windows)")
os_ver = re.compile(r"(Ubuntu|Debian|\s95)")
os_mac = re.compile(r"(Mac\s+OS)\s*([\d\.]+|X)")
graphic = re.compile(r"(X11)")
lang = re.compile(r"((en|de)[-_]\w\w)")
lang2 = re.compile(r"\[(en|de)\]")

text = ""

def guess():
    """
    Guess browser features.
    """
    info = {}
    # guess_one(text, model, "model model_ver", info)
    guess_one(browser, "browser browser_ver", info)
    guess_one(engine, "engine engine_ver", info)
    guess_one(os, "os", info)
    guess_one(os_ver, "os_ver", info)
    guess_one(os_mac, "os os_ver", info)
    guess_one(graphic, "graphic", info)
    if guess_one(arch, "arch", info):
        if info["arch"] == "PPC":
            info["arch"] = "PowerPC"
    guess_one(lang, "lang", info)
    guess_one(lang2, "lang", info)
    return info
