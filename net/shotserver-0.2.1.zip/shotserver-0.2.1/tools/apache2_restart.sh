#! /bin/sh
# Stupid hack to restart the web server. (Warrk! Stupidhack!)
# Call this with sudo.
apache2ctl stop
sleep 4
killall apache2
sleep 1
ipcrm sem `ipcs -s | grep www-data | cut -d' ' -f2`
sleep 1
apache2ctl start
