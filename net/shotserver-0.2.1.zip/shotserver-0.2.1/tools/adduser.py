# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Manually insert a browsershots user into the database, like this:
# python tools/adduser.py username password email
"""

__revision__ = '$Rev: 311 $'
__date__     = '$Date: 2005-04-04 23:49:50 +0200 (Mon, 04 Apr 2005) $'
__author__   = '$Author: johann $'

import sys
import MySQLdb

arg0, username, password, email = sys.argv

db_name = "browsershots02"
conn = MySQLdb.connect(host = "localhost", db = db_name,
                       user = db_name, passwd = "pa%sss" % db_name)
cursor = conn.cursor()

cursor.execute("INSERT INTO user SET" +
               " username = '%s'," % username +
               " password = PASSWORD('%s')," % password +
               " email = '%s'," % email +
               " verified = NOW(),"
               " registered = NOW()")

cursor.close()
conn.close()
