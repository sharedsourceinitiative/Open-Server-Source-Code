# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Show recently uploaded screenshots.
"""

__revision__ = '$Rev: 444 $'
__date__     = '$Date: 2005-05-19 10:19:36 +0200 (Thu, 19 May 2005) $'
__author__   = '$Author: johann $'

from liteweb import xhtml
from liteweb.xhtml import p

from shotserver02 import database as db
from shotserver02.database import job

def body(request_info):
    """
    User interface to show recently uploaded screenshots.
    """
    result = ''
    db.connect()
    shots = job.recently_uploaded()
    db.disconnect()

    for index, shot in enumerate(shots):
        if index >= 5:
            break

        attributes = {"src": "/png/240/%s-all.png" % shot["hashkey"],
                      "title": shot["url"],
                      "alt": "Screenshot of " + shot["url"],
                      "class": "preview240"}
        img = xhtml.tag3("img", attributes)

        attributes = {"href": request_info.href("website/%d" % shot["id"])}
        result += xhtml.tagline3("a", attributes, img)

    if result:
        return p("Click to see more screenshots of the same web site.") + \
               result + "&nbsp;\n"
    else:
        return p("No screenshots were uploaded recently.")
