# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Queue poll interface for screenshot factories.
"""

__revision__ = '$Rev: 362 $'
__date__     = '$Date: 2005-04-19 12:02:44 +0200 (Tue, 19 Apr 2005) $'
__author__   = '$Author: johann $'

from liteweb import xhtml
from liteweb.xhtml import p

from shotserver02 import database as db
from shotserver02.database import user, factory, job

def poll_form(options):
    """
    XHTML form for factory configuration.
    """
    result = ""
    keys = factory.keys[:]
    keys.append("username")
    keys.append("password")
    for key in keys:
        attributes = {"type": "text",
                      "name": key}
        if options.has_key(key):
            attributes["value"] = options[key]
        if key == "password":
            attributes["type"] = "password"
        field = xhtml.tag3("input", attributes)
        result += xhtml.tablerow((key, field))

    attributes = {"type": "submit"}
    button = xhtml.tag3("input", attributes)
    result += xhtml.tablerow(("", button))
    table = xhtml.tagline("table", "\n" + result)

    attributes = {"method": "post",
                  "action": "."}
    form = xhtml.tagline3("form", attributes, "\n" + table)
    return form

def upload_form(match):
    """
    XHTML form for upload of screenshots.
    """
    result = ""
    attributes = {"type": "text",
                  "size": 40,
                  "readonly": "readonly",
                  "name": "hashkey",
                  "value": match["hashkey"]}
    result += xhtml.tablerow(("hashkey",
                              xhtml.tag3("input", attributes)))

    attributes = {"type": "file",
                  "accept": "image/png"}
    for page in xrange(1, match["pgdn_count"] + 1):
        attributes["name"] = "pgdn%u" % page
        field = xhtml.tag3("input", attributes)
        doc = "page %u" % page
        if page == 1:
            doc = "top"
        result += xhtml.tablerow((doc, field))

    for page in xrange(match["pgup_count"], 0, -1):
        attributes["name"] = "pgup%u" % page
        field = xhtml.tag3("input", attributes)
        doc = "page -%u" % page
        if page == 1:
            doc = "bottom"
        result += xhtml.tablerow((doc, field))

    keys = []
    keys.append("username")
    keys.append("password")
    for key in keys:
        attributes = {"type": "text",
                      "name": key}
        if match.has_key(key):
            attributes["value"] = match[key]
        if key == "username":
            attributes["readonly"] = "readonly"
        if key == "password":
            attributes["type"] = "password"
        field = xhtml.tag3("input", attributes)
        result += xhtml.tablerow((key, field))

    attributes = {"type": "submit"}
    button = xhtml.tag3("input", attributes)
    result += xhtml.tablerow(("", button))
    table = xhtml.tagline("table", "\n" + result)

    attributes = {"method": "post",
                  "action": "/upload/",
                  "enctype": "multipart/form-data"}
    form = xhtml.tagline3("form", attributes, "\n" + table)
    return form

def form_options(form):
    """
    Extract options from post request.
    """
    options = {}
    for field in form.list:
        options[field.name] = field.value.strip()
    return options

def sanity_check(options, extra = None):
    """
    Check if submitted data make sense.
    """
    keys = factory.keys[:]
    if extra is not None:
        keys.extend(extra)
    for key in keys:
        if not options.has_key(key) \
               or not options[key]:
            return "No data for %s." % key
    return ""

def body(request_info):
    """
    Factory interface for polling the job queue.
    """
    if request_info.form:
        options = form_options(request_info.form)
        error = sanity_check(options, ["username", "password"])
        if error:
            return p("Error: " + error)

        username = options['username']
        password = options['password']

        db.connect()
        try:
            if not user.auth(username, password):
                return p("Error: Bad username/password.")
            factory_id = factory.polled(options)
            del(options["username"])
            del(options["password"])

            match = job.find(options)
            if match is None:
                return p("No matching job at this time.")
            match["username"] = username
            match["hashkey"] = job.locked(match["id"], factory_id)
            return upload_form(match)
        finally:
            db.disconnect()
    else:
        return poll_form({})
