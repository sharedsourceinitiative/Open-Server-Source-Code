# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Search queued and finished jobs.
"""

__revision__ = '$Rev: 456 $'
__date__     = '$Date: 2005-05-21 16:56:36 +0200 (Sat, 21 May 2005) $'
__author__   = '$Author: johann $'

from liteweb import xhtml, human
from liteweb.xhtml import p

import shotserver02.database as db

def address_field(options):
    """
    XHTML input field for web address.
    """
    return p(xhtml.tag3("input", {"type": "text",
                                  "size": "60",
                                  "name": "url",
                                  "value": options["url"]}))

def read_form(request_info):
    """
    Read information from post request.
    """
    url = ""
    if request_info.form:
        for field in request_info.form.list:
            if field.name == "url":
                url = field.value.strip()
            elif field.name == "submit":
                pass
            else:
                raise RuntimeError, "unknown field " + field.name
    return {"url": url}

def match_table(request_info, matches, max_matches, header):
    """
    XHTML table with matching URLs.
    """
    result = ""
    for index, match in enumerate(matches):
        if index >= max_matches:
            break
        text = match["url"]
        uri_core = "website/%d" % match["id"]
        attr = {"href": request_info.href(uri_core)}
        text = xhtml.tag3("a", attr, text)
        result += xhtml.tablerow([human.timespan(match["ago"]),
                                  match["count"], text])
    if result:
        header = xhtml.tablerow([header, _("Count"), _("URL")], "th")
        result = xhtml.tagline("table", "\n" + header + result)
    if len(matches) > max_matches:
        result += p("Another %d matching URLs are not shown.") % \
                  (len(matches) - max_matches)
    return result

def search(request_info, options):
    """
    Get matching jobs from database and display them in tables.
    """
    if not options["url"]:
        return ""

    db.connect()
    columns = "id, url, COUNT(id) AS count"
    columns += ", MIN(UNIX_TIMESTAMP()-UNIX_TIMESTAMP(uploaded)) AS ago"
    finished = db.select_some("job", columns,
                              "url LIKE '%%%s%%'" % options["url"] +
                              " AND NOT uploaded = 0" +
                              " GROUP BY url ORDER BY ago DESC")
    columns = "id, url, COUNT(id) AS count"
    columns += ", MAX(UNIX_TIMESTAMP()-UNIX_TIMESTAMP(submitted)) AS ago"
    queued = db.select_some("job", columns,
                            "url LIKE '%%%s%%'" % options["url"] +
                            " AND uploaded = 0" +
                            " GROUP BY url ORDER BY ago DESC")
    db.disconnect()

    # Finished and queued job search
    result = match_table(request_info, finished, 20, _("Finished")) + \
             match_table(request_info, queued, 20, _("Queued"))
    if result:
        return xhtml.tagline3("a", {"name": "results"}, "\n" + result)
    else:
        return p("No matching jobs.", "result")

def sanity_check_url(url):
    """
    Check the input URL for errors.
    """
    if url and len(url) < 3:
        return _("URL must not be shorter than 3 characters.")
    if url.count(" "):
        return _("URL must not contain spaces.")
    if url.count("'") or url.count('"'):
        return _("URL must not contain quotes.")

def sanity_check(options):
    """
    Check input for errors.
    """
    return sanity_check_url(options["url"])

def body(request_info):
    """
    User interface for searching jobs by URL.
    """
    result = ""
    # result += repr(read_form(request_info))
    options = read_form(request_info)

    result += p("Enter a part of your web address to find your jobs.")
    result += address_field(options)

    # Submit button
    buttons = "\n"
    buttons += xhtml.tagline3("input", {"type": "submit",
                                        "name": "submit",
                                        "value": _("Submit")})
    buttons += xhtml.tagline3("input", {"type": "reset",
                                        "name": "reset",
                                        "value": _("Reset")})
    result += p(buttons)

    attributes = {"action": request_info.href("search") + "#results",
                  "method": "post"}
    result = xhtml.tagline3("form", attributes, "\n" + result)

    error = sanity_check(options)
    if not error:
        result += search(request_info, options)
    else:
        result += p(error, "error")
    return result
