# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Upload screenshots.
"""

__revision__ = '$Rev: 440 $'
__date__     = '$Date: 2005-05-16 19:19:31 +0200 (Mon, 16 May 2005) $'
__author__   = '$Author: johann $'

import os

from liteweb.xhtml import p

from shotserver02 import images
from shotserver02.images import autoscroll

from shotserver02 import database as db
from shotserver02.database import job, factory

min_bytes = 1000
max_bytes = 2000000

def sanity_check(pngfilename, requested, delivered):
    """
    Sanity check an uploaded image.
    """
    if delivered["bytes"] < min_bytes:
        return "Uploaded image %s" % pngfilename + \
               " has only %d bytes," % delivered["bytes"] + \
               " which is less than the minimum of %d bytes." % min_bytes + \
               " If the file really contains a screenshot," + \
               " please file a bug report."
    if delivered["bytes"] > max_bytes:
        return "Uploaded image %s" % pngfilename + \
               " has %d bytes," % delivered["bytes"] + \
               " which is more than the maximum of %d bytes." % max_bytes + \
               " If the file really contains a screenshot," + \
               " please file a bug report."
    if delivered["resolution"] != requested["resolution"]:
        return "Uploaded image %s" % pngfilename + \
               " has wrong resolution %s," % delivered["resolution"] + \
               " should be %s." % requested["resolution"]
    return ""

def medium_parts(hashkey, files, parts, removed, prefix):
    """
    Produce medium size previews from parts that were not cropped away,
    for files going down from the top of the page.
    """
    if prefix == "pgdn":
        files.reverse()
        parts.reverse()
    pageno = len(files)
    for index, filename in enumerate(files):
        if removed < parts[index]:
            cutfile = filename + ".cut"
            page = "%s%d" % (prefix, pageno)
            if removed > 0:
                trimmed = cutfile + "t"
                if prefix == "pgdn":
                    command = "pnmcut -bottom -%d %s > %s" % \
                              (removed + 1, cutfile, trimmed)
                else:
                    command = "pnmcut -top %d %s > %s" % \
                              (removed, cutfile, trimmed)
                os.system(command)
                cutfile = trimmed
            if parts[index] > 0:
                images.pnmscaletopng(cutfile, 640, hashkey, page)
        removed = removed - parts[index]
        pageno -= 1

def join_files(hashkey, dnfiles, upfiles):
    """
    Join multiple page into one long screenshot.
    """
    allfile = "/tmp/" + hashkey + ".pnm"
    chrome = autoscroll.findchrome(dnfiles, upfiles)
    # return "w%d h%d t%d b%d" % (chrome["width"], chrome["height"],
    #                             chrome["top"], chrome["bottom"])

    if chrome["top"] == chrome["height"]: # all uploaded files are identical
        images.pnmscaletopng(dnfiles[0], 240, hashkey, "all")
        images.pnmscaletopng(dnfiles[0], 640, hashkey, "pgdn1")
    else: # find overlap between consecutive files and join them
        dnfile = dnfiles[0] + ".all"
        dnparts = autoscroll.join(dnfiles, dnfile, chrome, "top")
        upfile = upfiles[0] + ".all"
        upparts = autoscroll.join(upfiles, upfile, chrome, "bottom")
        removed = autoscroll.join2(dnfile, upfile, allfile)

        images.pnmscaletopng(allfile, 240, hashkey, "all")
        medium_parts(hashkey, dnfiles, dnparts, removed[0], "pgdn")
        medium_parts(hashkey, upfiles, upparts, removed[1], "pgup")

    autoscroll.system("rm /tmp/%s*.pnm*" % hashkey)

def upload_files(form, hashkey, requested):
    """
    Upload files, sanity check and join pages into one screenshot.
    """
    dnfiles = []
    upfiles = []
    for control in form.list:
        if control.filename:
            page = control.name
            pngfilename = images.copyfileobj(control.file, hashkey, page)
            pnmfilename = images.pngtopnm(pngfilename, hashkey, page)
            delivered = images.pnmheader(pnmfilename)
            delivered["bytes"] = os.path.getsize(pngfilename)

            error = sanity_check(control.filename, requested, delivered)
            if error:
                errorpath = "/var/www/browsershots.org/png/errors/"
                errorfilename = errorpath + os.path.basename(pngfilename)
                images.makeparent(errorfilename)
                os.rename(pngfilename, errorfilename)
                os.unlink(pnmfilename)
                return error

            if page.startswith("pgdn"):
                dnfiles.append(pnmfilename)
            if page.startswith("pgup"):
                upfiles.append(pnmfilename)

    dnfiles.sort()
    upfiles.sort()
    upfiles.reverse()

    # os.unlink(pnmfilename)
    return join_files(hashkey, dnfiles, upfiles)

def body(request_info):
    """
    Factory interface for uploading screenshots.
    """
    result = ""
    form = request_info.form
    hashkey = form.getfirst('hashkey').value
    result += p("Hashkey: %s") % hashkey

    db.connect()
    requested = db.select1_star("job", "hashkey = '%s'" % hashkey)
    requested["resolution"] = requested["resolution"].strip("%")
    factory_id = requested["factory"]
    db.disconnect()

    error = upload_files(form, hashkey, requested)
    if error:
        return p("Error: " + error)

    db.connect()
    job.uploaded(hashkey)
    factory.uploaded(factory_id)
    db.disconnect()
    return result
