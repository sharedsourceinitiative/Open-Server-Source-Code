# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Show recently uploaded screenshots.
"""

__revision__ = '$Rev: 447 $'
__date__     = '$Date: 2005-05-19 21:30:12 +0200 (Thu, 19 May 2005) $'
__author__   = '$Author: johann $'

from liteweb import xhtml, human
from liteweb.xhtml import p

import shotserver02.database as db

def queue_table(queue, hide_headers = False):
    result = ""
    for job in queue:
        age = human.timespan(job["age"])
        browser = job["browser"].rstrip("%")
        resolution = job["resolution"].rstrip("%")
        url = job["url"]
        result += xhtml.tablerow((age, browser, resolution, url))
    return result

def body(request_info):
    """
    User interface for showing all open jobs.
    """
    old_max = 50
    new_max = 50
    columns = "os, browser, engine, resolution, url"
    columns += ", UNIX_TIMESTAMP()-UNIX_TIMESTAMP(submitted) AS age"

    db.connect()
    count = db.select1_some("job", "COUNT(id) AS count", "uploaded = 0")
    count = int(count["count"])
    if count > old_max + new_max:
        oldest = db.select_some("job", columns, "uploaded = 0" +
                                " ORDER BY age DESC LIMIT %d" % old_max)
        newest = db.select_some("job", columns, "uploaded = 0" +
                                " ORDER BY age ASC LIMIT %d" % new_max)
    else:
        oldest = db.select_some("job", columns, "uploaded = 0" +
                                " ORDER BY age DESC")
        newest = []
    db.disconnect()

    newest = list(newest)
    newest.reverse()

    # Job queue table column headers
    header = (_("Time"), _("Browser"), _("Resolution"), _("URL"))
    header = xhtml.tablerow(header, "th")

    oldest = queue_table(oldest)
    newest = queue_table(newest, hide_headers = True)

    count = p("There are %d jobs in the queue.") % count
    if newest:
        return count + \
               xhtml.tagline3("table", {"class": "queue"}, "\n" +
                              header + oldest +
                              xhtml.tablerow(["..."]) +
                              newest)
    elif oldest:
        return count + \
               xhtml.tagline3("table", {"class": "queue"}, "\n" +
                              header + oldest)
    else:
        return p("The job queue is empty.")
