# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Add jobs to the queue.
"""

__revision__ = '$Rev: 467 $'
__date__     = '$Date: 2005-05-21 23:25:36 +0200 (Sat, 21 May 2005) $'
__author__   = '$Author: johann $'

import re

from liteweb import xhtml, human
from liteweb.xhtml import p

import shotserver02.database as db
from shotserver02.database import factory, job

def address_field(options):
    """
    XHTML input field for web address.
    """
    return p(xhtml.tag3("input", {"type": "text",
                                  "size": "60",
                                  "name": "url",
                                  "value": options["url"]}))

def browser_table(options):
    """
    XHTML table for selecting browsers.
    """
    db.connect()
    browsers = factory.active()
    db.disconnect()

    # Browser table column headers
    columns = "browser engine os polled uploaded".split(" ")
    doc = {'browser':   _('Browser name<br />and version'),
           'engine':    _('Rendering<br />engine'),
           'os':        _('Operating<br />system'),
           'polled':    _('Last<br />poll'),
           'uploaded':  _('Last<br />upload')}

    headers = []
    for column in columns:
        headers.append(doc[column])
    rows = xhtml.tablerow(headers, "th")

    count = 0
    minimum = 3
    factories = options["factories"]
    for browser in browsers:
        if count >= minimum and browser["polled"] > 12 * 3600:
            break
        attributes = {"type": "checkbox",
                      "name": "factory",
                      "value": browser["id"]}
        if browser["id"] in factories or not options["submitted"]:
            attributes["checked"] = "checked"
        checkbox = xhtml.tag3("input", attributes)
        row = []
        for column in columns:
            if column == "browser":
                row.append(checkbox + " " + browser["browser"])
            elif column in ("polled", "uploaded"):
                row.append(human.timespan(browser[column]))
            else:
                row.append(browser[column])
        rows += xhtml.tablerow(row)
        count += 1
    if not count:
        return p("No active screenshot factories.", "error")
    return xhtml.tagline3("table", {"class": "browsers"}, "\n" + rows)

def resolution_table(options):
    """
    XHTML table for selecting resolutions.
    """
    rows = ""
    blocks = "800x600 1024x768".split(" ")
    resolutions = options["resolutions"]
    if not options["submitted"]:
        resolutions = "800x600 1024x768".split(" ")
    for block in blocks:
        cells = []
        for resolution in block.split('-'):
            attributes = {"type": "checkbox",
                          "name": "resolution",
                          "value": resolution}
            if resolution in resolutions:
                attributes["checked"] = "checked"
            cells.append(xhtml.tag3("input", attributes) + " " + resolution)
        rows += xhtml.tablerow(cells)
    return xhtml.tagline3("table", {"class": "resolutions"}, "\n" + rows)

def page_table(options):
    """
    XHTML table for selecting pages for scrolling.
    """
    rows = ""
    attributes = {"type": "text",
                  "size": "2",
                  "maxlength": "5"}

    attributes["name"] = "pgdn"
    attributes["value"] = options["pgdn"]
    count = xhtml.tag3("input", attributes)
    rows += xhtml.tablerow((xhtml.tag("b", _("Top-down")),
                            count, _("pages")))

    attributes["name"] = "pgup"
    attributes["value"] = options["pgup"]
    count = xhtml.tag3("input", attributes)
    rows += xhtml.tablerow((xhtml.tag("b", _("Bottom-up")),
                            count, _("pages")))

    return xhtml.tagline3("table", {"class": "pages"}, "\n" + rows)

def min_max_pages(options):
    """
    Limit minimum and maximum page numbers.
    """
    pgdn = options["pgdn"]
    pgup = options["pgup"]
    if pgdn < 1:
        pgdn = 1 # pgdn must be at least 1
    if pgup < 1:
        pgup = 1 # pgup must be at least 1
    while True: # pgup + pgdn must be at most 6
        if pgup + pgdn <= 6:
            break
        if pgup > 1:
            pgup -= 1
        if pgup + pgdn <= 6:
            break
        if pgdn > 1:
            pgdn -= 1
    options["pgdn"] = pgdn
    options["pgup"] = pgup

def read_form(request_info):
    """
    Read information from post request.
    """
    url = "http://"
    factories = []
    resolutions = []
    pgdn = 2
    pgup = 1
    submitted = False
    if request_info.form:
        for field in request_info.form.list:
            if field.name == "url":
                url = field.value.strip()
            elif field.name == "factory":
                factories.append(int(field.value))
            elif field.name == "resolution":
                resolutions.append(field.value)
            elif field.name == "pgdn":
                pgdn = int(field.value)
            elif field.name == "pgup":
                pgup = int(field.value)
            elif field.name == "submit":
                submitted = True
            else:
                raise RuntimeError, "unknown field " + field.name

    result = {"username": 'anonymous',
              "url": url,
              "factories": factories,
              "resolutions": resolutions,
              "pgdn": pgdn,
              "pgup": pgup,
              "submitted": submitted}
    min_max_pages(result)
    return result

def already_in_queue(queue, browser, resolution):
    """
    Check if a job is already in the queue.
    This is used to prevent duplicates.
    """
    if queue is None:
        return False
    for queuejob in queue:
        if queuejob["browser"].startswith(browser) and \
           queuejob["resolution"].startswith(resolution):
            return True
    return False

def submit(options):
    """
    Insert new jobs into database table.
    """
    db.connect()
    queue = job.open_jobs_by_url(options["url"])
    added = skipped = ""
    for factory_id in options["factories"]:
        info = db.select1_star("factory", "id = %u" % factory_id)
        browser = info["browser"]
        for resolution in options["resolutions"]:
            if already_in_queue(queue, browser, resolution):
                skipped += xhtml.tablerow((browser, resolution))
            else:
                options["browser"] = browser
                options["resolution"] = resolution
                job.insert(options)
                added += xhtml.tablerow((browser, resolution))
    db.disconnect()

    result = ""
    if added:
        result += p("The following jobs were added to the queue:", "success")
        result += xhtml.tagline3("table", {"class": "queue"}, "\n" + added)
    if skipped:
        result += p("The following jobs were already in the queue:", "error")
        result += xhtml.tagline3("table", {"class": "queue"}, "\n" + skipped)
    if result:
        result = xhtml.tagline3("a", {"name": "results"}, "\n" + result)
    return result

re_url = re.compile(r"http://\w+\.\w+")

def sanity_check_url(url):
    """
    Check for invalid URLs.
    """
    if url == "http://":
        return _("Please enter your URL.")
    if not url.startswith("http://"):
        return _('URL must start with <span class="uncolor">http://</span>.')
    if url.count(" "):
        return _("URL must not contain spaces.")
    if url.count("'") or url.count('"'):
        return _("URL must not contain quotes.")
    if url.count("<") or url.count(">"):
        return _("URL must not contain HTML tags.")
    if url.count(".") == 0:
        return _("URL must contain at least one dot.")
    if not re_url.match(url):
        return _("URL seems to be invalid.")

def sanity_check_factories(factories):
    """
    Check for invalid factory selection.
    """
    if len(factories) == 0:
        return _("Please select at least one browser.")

def sanity_check_resolutions(resolutions):
    """
    Check for invalid resolution selection.
    """
    if len(resolutions) == 0:
        return _("Please select at least one screen resolution.")

def sanity_check(options):
    """
    Check for invalid input.
    """
    error = sanity_check_url(options["url"])
    if error:
        return error
    error = sanity_check_factories(options["factories"])
    if error:
        return error
    error = sanity_check_resolutions(options["resolutions"])
    if error:
        return error

def body(request_info):
    """
    User interface for submitting jobs.
    """
    result = ""
    # result += repr(read_form(request_info))
    options = read_form(request_info)

    result += p("Enter your web address.")
    result += address_field(options)

    result += p("Select the browsers that you would like to test.")
    result += browser_table(options)

    result += p("Select one or more screen resolutions.")
    result += resolution_table(options)

    result += p("Select pages for scrolling.")
    result += page_table(options)

    # Submit button
    result += p(xhtml.tagline3("input", {"type": "submit",
                                         "name": "submit",
                                         "value": _("Submit")}) +
              xhtml.tagline3("input", {"type": "reset",
                                       "name": "reset",
                                       "value": _("Reset")}))

    attributes = {"action": request_info.href("submit") + "#results",
                  "method": "post"}
    result = xhtml.tagline3("form", attributes, "\n" + result)

    if options["submitted"]:
        error = sanity_check(options)
        if error:
            result += p(error, "error")
        else:
            result += submit(options)

    return result
