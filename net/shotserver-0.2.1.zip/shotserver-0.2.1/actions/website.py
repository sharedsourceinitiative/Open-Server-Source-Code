# Browsershots
# Copyright (C) 2005 Johann C. Rocholl <johann@rocholl.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston,
# MA 02111-1307, USA.

"""
Show all recently uploaded screenshots for one web site.
"""

__revision__ = '$Rev: 329 $'
__date__     = '$Date: 2005-04-09 12:04:51 +0200 (Sat, 09 Apr 2005) $'
__author__   = '$Author: johann $'

from liteweb import xhtml
from liteweb.xhtml import p

from shotserver02 import database as db
from shotserver02.database import job

import re

re_numeric = re.compile(r"(\d+)x(\d+)")

def numeric(resolution):
    match = re_numeric.match(resolution)
    if not match:
        return (0, 0)
    return (int(match.group(1)),
            int(match.group(2)))

def body(request_info):
    """
    User interface to show recently uploaded screenshots for one web site.
    """
    result = ''
    job_id = int(request_info.uri.parts[1])

    db.connect()
    url = db.select1_column("job", "url", "id = %d" % job_id)
    shots = job.finished_by_url(url)
    db.disconnect()

    sizeshots = {}
    for shot in shots:
        browser = shot["browser"]
        browser = browser.strip("%")
        attributes = {"src": "/png/240/%s-all.png" % shot["hashkey"],
                      "alt": "Screenshot of " + browser,
                      "title": browser,
                      "class": "preview240"}
        img = xhtml.tag3("img", attributes)

        attributes = {"href": request_info.href("job/%d" % shot["id"])}
        link = xhtml.tagline3("a", attributes, img)

        size = numeric(shot["resolution"])
        if not sizeshots.has_key(size):
            sizeshots[size] = ""
        sizeshots[size] += link

    sizes = sizeshots.keys()
    sizes.sort()
    for size in sizes:
        result += xhtml.tagline("h2", "%dx%d" % size)
        result += sizeshots[size] + "&nbsp;\n"

    if result:
        return p("Click to see a larger preview.") + \
               result
    else:
        return p("No screenshots were uploaded recently.")
